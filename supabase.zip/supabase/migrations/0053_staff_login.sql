-- 0053: Staff-ID login.
-- Staff can sign in with a staff code instead of their email.
-- Preferred form (HR Add Employee):  <prefix>-<4 digits>  e.g.  vy-1000
--   stored on company_members.employee_no (unique per company).
-- Legacy form:  <company code>-<employee_no> when employee_no is not already prefix-digits.
--
-- The "staff-login" Edge Function resolves the code to the account email (service
-- role) and signs in. This view is readable ONLY by the service role, so emails can
-- never be enumerated from the browser.
--
-- Cursor 2026-10-24: accept HR prefix+4digit staff IDs (vy-1000) as the login code.

create or replace view staff_login_lookup
  with (security_invoker = true) as
select
  case
    when m.employee_no ~* '^[a-z0-9]+-[0-9]{4}$' then lower(m.employee_no)
    else lower(c.code || '-' || m.employee_no)
  end as login_code,
  p.email                                as email,
  c.status                               as company_status
from company_members m
join companies c on c.id = m.company_id
join profiles  p on p.id = m.user_id
where m.employee_no is not null
  and m.employee_no <> ''
  and p.email is not null;

revoke all on staff_login_lookup from anon, authenticated;
grant select on staff_login_lookup to service_role;
