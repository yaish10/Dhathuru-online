/* Public Supabase settings. The publishable key is safe in the browser because RLS guards every table. Never put the secret key here. */
window.VEYORA_CONFIG = {
  supabaseUrl: "https://wafmlvucucfrvnlkkcnh.supabase.co",
  supabaseKey: "sb_publishable_Jk95JxklXN7Cb43Fqo6wpQ_tLWB2xRT"
};
