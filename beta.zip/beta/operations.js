/* Operations: trip dispatch board (operations.html) — Today / Upcoming / Completed / Cancelled + crew board.
   Data: ops_board (today: KPIs, queue), schedule_trips (two weeks back, a month ahead), scan_operations on load.
   Actions: clear_trip, set_trip_status, finish_dispatch_task, insert into trips. See supabase/DATABASE_HANDOFF.md §3.7. */
(function () {
  var db = window.veyoraDb;
  var esc = window.VeyoraShell.esc;
  var $ = function (id) { return document.getElementById(id); };
  var company = null, canOps = false;
  var tab = "today", q = "", statusF = "", routeF = "", vesselF = "", dayF = "";
  var trips = [];      // schedule_trips rows mapped by view()
  var queue = [];      // ops_board.queue
  var kp = null;       // ops_board.kpis
  var routes = [], vessels = [], staff = []; // staff: [{id, name}] active employees (captain picker)
  // Assign-vessel drawer: { tripId, vesselId, q }
  var assign = null;

  function icon(p) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + p + '</svg>'; }
  var I = {
    boat: '<path d="M4 15h16l-2 5H6zM8 15V9h8v6M12 9V4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    alert: '<path d="M12 4 3 20h18L12 4ZM12 10v4M12 17h.01"/>',
    people: '<path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 4-6 8-6s8 2 8 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    person: '<path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 4-6 8-6s8 2 8 6"/>',
    more: '<circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>',
    warn: '<path d="M12 4 3 20h18L12 4ZM12 10v4M12 17h.01"/>',
    ok: '<path d="m5 12 5 5 9-10"/>',
    chev: '<path d="m9 6 6 6-6 6"/>',
    pin: '<path d="M12 21s7-5.2 7-11a7 7 0 1 0-14 0c0 5.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    vessel: '<path d="M3 16h18l-2 4H5l-2-4ZM6 16V9h12v7M9 9V6h6v3"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    print: '<path d="M6 9V4h12v5M6 14H4a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2M6 14h12v6H6z"/>',
    hourglass: '<path d="M6 4h12M6 20h12M8 4v3l4 5-4 5v3M16 4v3l-4 5 4 5v3"/>',
    check: '<path d="m5 12 5 5 9-10"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>'
  };
  function slug(t) { return String(t || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); }
  function chip(text, cls) { return '<span class="chip ' + (cls || "st-" + slug(text)) + '">' + esc(text) + '</span>'; }
  function initials(name) {
    var s = String(name == null || name === "" ? "?" : name).trim();
    return s.split(/\s+/).filter(Boolean).map(function (w) { return w.charAt(0); }).join("").slice(0, 2).toUpperCase() || "?";
  }
  function seatPct(booked, total) {
    if (total == null || total <= 0 || booked == null) return null;
    return Math.max(0, Math.round((Number(booked) / Number(total)) * 100));
  }
  // Passenger load vs vessel seats: ok → almost (≥85%) → full (≥100%).
  function loadState(booked, total) {
    var pct = seatPct(booked, total);
    if (pct == null) return { pct: null, level: "", label: "", cls: "" };
    if (pct >= 100) return { pct: pct, level: "full", label: "Vessel full", cls: "load-full" };
    if (pct >= 85) return { pct: pct, level: "almost", label: "Almost full", cls: "load-almost" };
    return { pct: pct, level: "ok", label: "", cls: "" };
  }
  function loadChip(booked, total) {
    var s = loadState(booked, total);
    if (!s.level || s.level === "ok") return "";
    return '<span class="ops-load-chip ' + s.cls + '">' + esc(s.label) + '</span>';
  }
  function loadBanner(booked, total, vesselName) {
    var s = loadState(booked, total);
    if (!s.level || s.level === "ok") return "";
    var who = vesselName ? esc(vesselName) : "This vessel";
    var msg = s.level === "full"
      ? who + " is full — no seats left for more passengers."
      : who + " is almost full (" + s.pct + "% of seats booked).";
    return '<div class="ops-load-banner ' + s.cls + '" role="status">' + icon(I.alert) + '<span>' + msg + '</span></div>';
  }
  function statusTone(status) {
    var s = slug(status);
    if (s === "delayed") return "amber";
    if (s === "cancelled") return "rose";
    if (s === "on-time" || s === "arrived" || s === "completed") return "teal";
    if (s === "boarding" || s === "departed" || s === "in-transit" || s === "en-route") return "live";
    return "slate";
  }
  function loadBar(booked, total) {
    var s = loadState(booked, total);
    var label = (booked != null ? booked : "—") + " / " + (total != null ? total : "—");
    if (s.pct == null) return '<span class="ops-load ops-load-na">' + icon(I.person) + ' ' + esc(label) + '</span>';
    var fill = s.level === "full" ? " hot" : s.level === "almost" ? " warm" : (s.pct >= 70 ? " warm" : "");
    var tip = s.label ? s.label + " · " + s.pct + "%" : s.pct + "% full";
    return '<span class="ops-load ' + s.cls + '" title="' + esc(tip) + '">' +
      '<span class="ops-load-track"><span class="ops-load-fill' + fill + '" style="width:' + Math.min(100, s.pct) + '%"></span></span>' +
      '<span class="ops-load-txt">' + esc(label) + '</span>' +
      (s.label ? '<span class="ops-load-tag">' + esc(s.label) + '</span>' : "") +
    '</span>';
  }
  function journeyStrip(origin, dest, compact) {
    var a = origin || "Origin", b = dest || "Destination";
    return '<div class="ops-journey' + (compact ? " compact" : "") + '">' +
      '<span class="ops-port"><span class="ops-dot"></span><span class="ops-port-name">' + esc(a) + '</span></span>' +
      '<span class="ops-rail" aria-hidden="true"><span class="ops-rail-line"></span><span class="ops-rail-boat">' + icon(I.boat) + '</span></span>' +
      '<span class="ops-port end"><span class="ops-dot"></span><span class="ops-port-name">' + esc(b) + '</span></span>' +
      '</div>';
  }
  function pad2(n) { return n < 10 ? "0" + n : String(n); }
  function iso(d) { return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
  function todayIso() { return iso(new Date()); }
  function addDays(s, n) { var d = new Date(s + "T00:00:00"); d.setDate(d.getDate() + n); return iso(d); }
  function rpc(name, args) {
    return db.rpc(name, args).then(function (r) { if (r.error) throw new Error(r.error.message); return r.data; });
  }
  var CLOSED = ["Cancelled", "Arrived", "Completed"];

  // schedule_trips row → board row. "On time" is shown for a cleared trip that is still Scheduled (not stored).
  function view(t) {
    var d = new Date(t.depart_at);
    var arr = t.arrive_at ? new Date(t.arrive_at) : null;
    var crewList = Array.isArray(t.crew) ? t.crew : [];
    var status = t.status === "Scheduled" && t.cleared_at ? "On time" : t.status;
    if (status === "Departed" || status === "In transit") status = "En Route";
    return {
      id: t.id, code: t.code, day: iso(d), time: pad2(d.getHours()) + ":" + pad2(d.getMinutes()),
      arrive: arr ? pad2(arr.getHours()) + ":" + pad2(arr.getMinutes()) : "",
      route: t.route, route_id: t.route_id,
      origin: t.origin || "", destination: t.destination || "",
      corridor: (t.origin || "") + " → " + (t.destination || ""),
      vessel: t.vessel || "", vessel_id: t.vessel_id, vesselCode: t.vessel_code || "", vesselKind: t.kind, captain: t.captain,
      crewCount: crewList.length, crewList: crewList, departTs: d.getTime(), arriveTs: arr ? arr.getTime() : null, reason: t.status_reason || "",
      booked: t.seats_booked, capacity: t.seats_total, cleared: !!t.cleared_at,
      status: status, raw: t
    };
  }

  /* ---------- modern board helpers ---------- */
  function vesselOf(t) { return (vessels || []).filter(function (v) { return v.id === t.vessel_id; })[0]; }
  function mixOf(t) { var v = vesselOf(t), m = v && v.meta && v.meta.crew_mix; return Array.isArray(m) ? m : []; }
  // Crew needed on a trip (vessel crew needs, captain included) and how many are on it now.
  function crewFill(t) {
    var need = mixOf(t).reduce(function (n, x) { return n + (Number(x.n) || 0); }, 0);
    return { have: (t.captain ? 1 : 0) + (t.crewCount || 0), need: need };
  }
  function avatars(t, max) {
    var names = (t.captain ? [{ name: t.captain, role: "Captain" }] : []).concat((t.crewList || []).map(function (c) { return { name: c.name, role: c.role }; }));
    if (!names.length) return '<span class="ops-av-empty">No crew</span>';
    var shown = names.slice(0, max || 4);
    return '<span class="ops-avs">' + shown.map(function (x, i) {
      return '<span class="ops-av r-' + slug(x.role || "crew") + '" style="z-index:' + (10 - i) + '" title="' + esc((x.name || "") + " · " + (x.role || "")) + '">' + esc(initials(x.name)) + '</span>';
    }).join("") + (names.length > shown.length ? '<span class="ops-av more">+' + (names.length - shown.length) + '</span>' : "") + '</span>';
  }
  function fillChip(t) {
    var f = crewFill(t); if (!f.need) return "";
    var cls = f.have >= f.need ? "full" : f.have ? "part" : "none";
    return '<span class="ops-fill ' + cls + '" title="Crew on this trip / crew the vessel needs">' + f.have + "/" + f.need + ' crew</span>';
  }
  function untilText(ms) {
    var m = Math.round(ms / 60000); if (m <= 0) return "now";
    if (m < 60) return "in " + m + " min";
    var h = Math.floor(m / 60), r = m % 60; return "in " + h + "h" + (r ? " " + pad2(r) + "m" : "");
  }
  function progressOf(t) {
    if (!t.arriveTs) return null; var now = Date.now();
    if (now <= t.departTs) return 0; if (now >= t.arriveTs) return 100;
    return Math.round((now - t.departTs) * 100 / (t.arriveTs - t.departTs));
  }
  function isLive(t) { return t.status === "Boarding" || t.status === "En Route"; }
  function tabCounts() {
    var today = todayIso(), c = { today: 0, upcoming: 0, crew: 0, completed: 0, cancelled: 0 };
    trips.forEach(function (t) {
      var st = t.raw.status;
      if (t.day === today) c.today++;
      if (t.day > today && CLOSED.indexOf(st) < 0) c.upcoming++;
      if (t.day === (dayF || today) && CLOSED.indexOf(st) < 0) { var f = crewFill(t); if (!f.need || f.have < f.need) c.crew++; }
      if (st === "Arrived" || st === "Completed") c.completed++;
      if (st === "Cancelled") c.cancelled++;
    });
    return c;
  }
  // Today: the next sailing and anything under way right now.
  function liveStrip() {
    if (tab !== "today" || dayF) return "";
    var now = Date.now(), today = todayIso();
    var live = trips.filter(function (t) { return t.day === today && isLive(t); });
    var next = trips.filter(function (t) { return t.departTs > now && CLOSED.indexOf(t.raw.status) < 0 && t.raw.status !== "Cancelled"; }).sort(function (a, b) { return a.departTs - b.departTs; })[0];
    if (!live.length && !next) return "";
    return '<div class="ops-live">' +
      (next ? '<button type="button" class="ops-next" data-trip="' + esc(next.id) + '">' +
        '<span class="ops-next-k">Next departure</span>' +
        '<span class="ops-next-time"><strong>' + esc(next.time) + '</strong><em data-until="' + next.departTs + '">' + esc(untilText(next.departTs - now)) + '</em></span>' +
        '<span class="ops-next-route">' + esc(next.origin || "") + ' ' + icon(I.arrow) + ' ' + esc(next.destination || "") + '</span>' +
        '<span class="ops-next-meta">' + icon(I.vessel) + esc(next.vesselCode || next.vessel || "No vessel") + ' · ' + esc(next.code || "") + '</span>' +
        '<span class="ops-next-crew">' + avatars(next, 5) + fillChip(next) + '</span></button>' : "") +
      (live.length ? '<div class="ops-under-way"><span class="ops-next-k"><i class="ops-pulse"></i>Under way now</span>' + live.map(function (t) {
        var p = progressOf(t);
        return '<button type="button" class="ops-uw" data-trip="' + esc(t.id) + '"><span class="ops-uw-top"><strong>' + esc(t.vesselCode || t.vessel || t.code) + '</strong><small>' + esc(t.origin) + ' → ' + esc(t.destination) + '</small>' + chip(statusLabel(t.status)) + '</span>' +
          '<span class="ops-uw-bar"><span style="width:' + (p == null ? 0 : p) + '%"></span><i style="left:' + (p == null ? 0 : p) + '%">' + icon(I.boat) + '</i></span>' +
          '<span class="ops-uw-foot"><small>' + esc(t.time) + '</small><small>' + (t.arrive ? "arr " + esc(t.arrive) : "") + '</small></span></button>';
      }).join("") + '</div>' : "") +
    '</div>';
  }
  function dayLabel(day) {
    var d = new Date(day + "T00:00:00"), today = todayIso();
    if (day === today) return "Today";
    if (day === addDays(today, 1)) return "Tomorrow";
    if (day === addDays(today, -1)) return "Yesterday";
    return d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short" });
  }
  // Upcoming / Completed / Cancelled: trips grouped under day headers.
  function listByDay(list) {
    if (tab === "today" && !dayF) return '<div class="ops-list">' + list.map(tripRow).join("") + '</div>';
    var days = [], by = {};
    list.forEach(function (t) { if (!by[t.day]) { by[t.day] = []; days.push(t.day); } by[t.day].push(t); });
    if (tab === "completed" || tab === "cancelled") days.reverse();
    return days.map(function (d) {
      return '<div class="ops-day"><div class="ops-day-head"><strong>' + esc(dayLabel(d)) + '</strong><span>' + by[d].length + (by[d].length === 1 ? " trip" : " trips") + '</span></div>' +
        '<div class="ops-list">' + by[d].map(tripRow).join("") + '</div></div>';
    }).join("");
  }

  function statusLabel(s) {
    if (s === "Departed" || s === "In transit") return "En Route";
    return s;
  }
  function kpis() {
    var k = kp || {};
    var active = k.active || 0, delayed = k.delayed || 0, crew = k.crew_on_duty || 0;
    var avail = (vessels || []).filter(function (v) { return v.status !== "Out of service" && v.status !== "Maintenance"; }).length;
    return {
      active: active, activeHint: "Live sailings",
      delayed: delayed, delayedHint: delayed ? "Need attention" : "None delayed",
      vessels: avail, vesselsHint: "Ready to assign",
      crew: crew, crewHint: crew ? "On duty now" : "Ready for duty"
    };
  }
  function boardTitle() {
    if (tab === "crew") return "Crew management";
    if (dayF) return "Trips · " + dayF.slice(8) + "/" + dayF.slice(5, 7) + "/" + dayF.slice(0, 4);
    if (tab === "upcoming") return "Upcoming trips";
    if (tab === "completed") return "Completed trips";
    if (tab === "cancelled") return "Cancelled trips";
    return "Today's Trips";
  }
  function crewDayTrips() {
    var day = dayF || todayIso();
    return trips.filter(function (t) {
      return t.day === day && CLOSED.indexOf(t.raw.status) < 0 && t.raw.status !== "Cancelled";
    });
  }
  function crewBoard() {
    var list = crewDayTrips();
    if (!list.length) {
      return '<div class="ops-empty"><span class="ic">' + icon(I.people) + '</span>' +
        '<h3>No open trips to crew</h3><p>Pick another date or publish sailings from Schedules.</p></div>';
    }
    var full = list.filter(function (t) { var f = crewFill(t); return f.need && f.have >= f.need; }).length, sized = list.filter(function (t) { return crewFill(t).need; }).length;
    var pct = sized ? Math.round(full * 100 / sized) : 0;
    return '<div class="ops-crew-board">' +
      '<div class="ops-crew-hero"><div class="ops-ring" style="--p:' + pct + '"><span><strong>' + pct + '%</strong><small>crewed</small></span></div>' +
        '<div class="grow"><strong>' + full + ' of ' + sized + ' sailings fully crewed</strong><p class="note">' + (dayF ? "Sailings on " + esc(dayLabel(dayF)) : "Today’s open sailings") + '. Crew fill themselves from the Duty Roster using each boat’s crew needs; you can change anyone here.</p></div></div>' +
      (canOps ? '<p style="margin:0 0 14px;display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="btn-soft" id="crewAutoAll">' + icon(I.people) + ' Fill empty places from roster</button><button type="button" class="btn-soft" id="vesselCrewNeeds">' + icon(I.boat) + ' Vessel crew needs</button></p>' : "") +
      list.map(function (t) {
        var crew = Array.isArray(t.raw.crew) ? t.raw.crew : [];
        var closed = CLOSED.indexOf(t.raw.status) >= 0;
        var mix = mixOf(t), seatsHtml = "";
        if (mix.length) {
          var pool = crew.slice();
          seatsHtml = '<div class="ops-seats">' + mix.map(function (m) {
            var role = String(m.role), n = Number(m.n) || 0, out = [], isCapt = /^(captain|master|skipper)s?$/i.test(role.trim());
            for (var k = 0; k < n; k++) {
              var who = null;
              if (isCapt && k === 0 && t.captain) who = { name: t.captain };
              else { var ix = -1; pool.forEach(function (c, j) { if (ix < 0 && String(c.role || "").toLowerCase() === role.toLowerCase()) ix = j; }); if (ix > -1) who = pool.splice(ix, 1)[0]; }
              out.push(who ? '<span class="ops-seat on r-' + slug(role) + '" title="' + esc(who.name + " · " + role) + '"><b>' + esc(initials(who.name)) + '</b><small>' + esc(String(who.name).split(/\s+/)[0]) + '</small></span>'
                : '<span class="ops-seat open" title="Needs a ' + esc(role) + '"><b>+</b><small>' + esc(role) + '</small></span>');
            }
            return out.join("");
          }).join("") + '</div>';
        }
        var f = crewFill(t);
        return '<article class="ops-crew-trip' + (f.need ? (f.have >= f.need ? " is-full" : " is-short") : "") + '">' +
          '<header class="ops-crew-trip-head">' +
            '<div class="ops-crew-when"><span class="ops-crew-time">' + esc(t.time) + '</span><div><strong>' + esc((t.origin || "?") + " → " + (t.destination || "?")) + '</strong>' +
              '<small>' + esc(t.code || "Trip") + (t.vesselCode || t.vessel ? " · " + (t.vesselCode || t.vessel) : "") + '</small></div></div>' +
            '<div class="ops-crew-trip-acts">' + fillChip(t) + chip(statusLabel(t.status)) +
              '<button type="button" class="btn-soft" data-trip="' + esc(t.id) + '" data-opentab="crew">Open</button></div>' +
          '</header>' + seatsHtml +
          '<div class="ops-crew-fields">' +
            '<div class="fld"><label>Captain</label>' +
              (canOps && !closed
                ? '<select data-captain-trip="' + esc(t.id) + '">' + options(staff || [], t.raw.captain_id || "", "No captain") + '</select>'
                : '<strong class="ops-crew-static">' + esc(t.captain || "Unassigned") + '</strong>') +
            '</div>' +
            '<div class="fld grow"><label>Crew on this trip</label>' +
              '<div class="ops-crew-chips">' +
                (crew.length ? crew.map(function (c) {
                  return '<span class="ops-crew-chip"><span class="av">' + esc(initials(c.name)) + '</span>' +
                    '<span><strong>' + esc(c.name || "Crew") + '</strong><small>' + esc(c.role || "Crew") + '</small></span>' +
                    (canOps && !closed ? '<button type="button" class="ghost" data-board-uncrew="' + esc(t.id) + '" data-uid="' + esc(c.user_id) + '" title="Remove">×</button>' : "") +
                  '</span>';
                }).join("") : '<span class="note">No crew yet</span>') +
              '</div>' +
              (canOps && !closed ?
                '<div class="ops-crew-add">' +
                  '<select data-add-user="' + esc(t.id) + '">' + options(staff || [], "", "Add person") + '</select>' +
                  '<select data-add-role="' + esc(t.id) + '"><option>Crew</option><option>Cashier</option><option>Deck</option><option>Engineering</option><option>Cabin</option></select>' +
                  '<button type="button" class="btn-soft" data-board-add="' + esc(t.id) + '">Add</button>' +
                '</div>' : "") +
            '</div>' +
          '</div></article>';
      }).join("") +
    '</div>';
  }
  function filtered() {
    var today = todayIso();
    return trips.filter(function (t) {
      var st = t.raw.status;
      if (dayF) {
        if (t.day !== dayF) return false;
      } else {
        if (tab === "today" && t.day !== today) return false;
        if (tab === "upcoming" && !(t.day > today && CLOSED.indexOf(st) < 0)) return false;
      }
      if (tab === "completed" && st !== "Arrived" && st !== "Completed") return false;
      if (tab === "cancelled" && st !== "Cancelled") return false;
      if (statusF && t.status !== statusF) return false;
      if (routeF && t.route_id !== routeF) return false;
      if (vesselF && t.vessel_id !== vesselF) return false;
      if (q) {
        var hay = (t.route + " " + t.vessel + " " + (t.captain || "") + " " + (t.code || "")).toLowerCase();
        if (hay.indexOf(q.toLowerCase()) < 0) return false;
      }
      return true;
    });
  }

  function emptyBoard() {
    var labels = { today: "today", upcoming: "upcoming", completed: "completed", cancelled: "cancelled" };
    var when = dayF ? ("on " + dayF.slice(8) + "/" + dayF.slice(5, 7) + "/" + dayF.slice(0, 4)) : (labels[tab] || "");
    return '<div class="ops-empty"><span class="ic">' + icon(I.boat) + '</span>' +
      '<h3>No trips ' + esc(when) + '</h3>' +
      '<p>' + (dayF ? "Nothing matches this date. Clear the date filter or pick another day." : (tab === "today" ? "Nothing is sailing today. Create a one-off trip or publish sailings from Schedules." : "Nothing to show here for the last two weeks and the next month.")) + '</p>' +
      '<div class="acts">' +
        (dayF ? '<button type="button" class="btn-soft" id="clearDay">Clear date</button>' : "") +
        (canOps ? '<button type="button" class="primary-btn" id="emptyNew">' + icon(I.plus) + ' New trip</button><a class="btn-soft" href="schedules.html">Open Schedules</a>' : '<a class="btn-soft" href="schedules.html">Open Schedules</a>') +
      '</div></div>';
  }

  function vesselSlot(t) {
    var closed = CLOSED.indexOf(t.raw.status) >= 0 || t.raw.status === "Cancelled";
    if (t.vessel_id || t.vessel) {
      return '<div class="ops-vslot has' + (canOps && !closed ? " clickable" : "") + '"' +
        (canOps && !closed ? ' role="button" tabindex="0" data-assign="' + esc(t.id) + '"' : "") +
        ' title="' + esc(t.vessel || "Change vessel") + '">' +
        '<span class="ops-vslot-ic">' + icon(I.vessel) + '</span>' +
        '<span class="ops-vslot-txt"><strong>' + esc(t.vesselCode || t.vessel) + '</strong>' +
          '<small><i class="ops-dot-ok"></i> Assigned</small></span>' +
        (canOps && !closed
          ? '<button type="button" class="ops-vslot-x" data-unassign="' + esc(t.id) + '" title="Remove vessel" aria-label="Remove vessel">' + icon(I.x) + '</button>'
          : "") +
      '</div>';
    }
    if (!canOps || closed) return '<div class="ops-vslot empty muted">No vessel</div>';
    return '<button type="button" class="ops-vslot assign" data-assign="' + esc(t.id) + '">' +
      icon(I.vessel) + '<span>Assign Vessel</span></button>';
  }

  function tripRow(t) {
    var tone = statusTone(t.status);
    var showDay = !!dayF || tab !== "today" || t.day !== todayIso();
    var label = (t.code ? t.code + " · " : "") + t.route + " " + t.time;
    var capt = t.captain ? ("Capt. " + String(t.captain).split(/\s+/).slice(0, 2).join(" ")) : "Unassigned";
    var crewBit = capt + (t.crewCount ? " / " + t.crewCount : "");
    var st = statusLabel(t.status);
    var load = loadState(t.booked, t.capacity);
    return '<article class="ops-row tone-' + tone + (load.cls ? " " + load.cls : "") + '" role="button" tabindex="0" data-trip="' + esc(t.id) + '" aria-label="Open trip ' + esc(label) + '">' +
      '<div class="ops-row-id"><span class="ops-row-ic">' + icon(I.vessel) + '</span>' +
        '<div><strong>' + esc(t.code || "Trip") + '</strong>' +
        (showDay ? '<small>' + esc(t.day.slice(8) + "/" + t.day.slice(5, 7)) + '</small>' : "") +
      '</div></div>' +
      '<div class="ops-row-time"><strong>' + esc(t.time) + '</strong>' + (t.arrive ? '<small>arr ' + esc(t.arrive) + '</small>' : "") + '</div>' +
      '<div class="ops-row-route">' +
        '<strong>' + esc(t.origin || "Origin") + '</strong>' +
        '<span class="ops-row-arrow" aria-hidden="true">' + icon(I.arrow) + '</span>' +
        '<strong>' + esc(t.destination || "Destination") + '</strong>' +
      '</div>' +
      '<div class="ops-row-meta">' +
        '<span class="ops-row-crew" title="' + esc(crewBit) + '">' + avatars(t, 4) + fillChip(t) + '</span>' +
        loadBar(t.booked, t.capacity) +
        loadChip(t.booked, t.capacity) +
        (t.reason && (t.raw.status === "Delayed" || t.raw.status === "Cancelled") ? '<span class="ops-row-reason">' + icon(I.alert) + ' ' + esc(t.reason) + '</span>' : "") +
      '</div>' +
      vesselSlot(t) +
      '<div class="ops-row-status">' + (isLive(t) ? '<i class="ops-pulse"></i>' : "") + chip(st) + '<span class="ops-row-open" aria-hidden="true">' + icon(I.chev) + '</span></div>' +
      (t.status === "En Route" && progressOf(t) != null ? '<span class="ops-row-prog" aria-hidden="true"><span style="width:' + progressOf(t) + '%"></span></span>' : "") +
    '</article>';
  }

  function queueBlock() {
    if (!queue.length) return '<div class="empty-side">No dispatch tasks right now.</div>';
    return '<div class="ops-queue">' + queue.map(function (x) {
      var pri = x.priority === "High" ? "pri-high" : x.priority === "Due" ? "pri-due" : "pri-review";
      var priLabel = x.priority === "Due" ? "Medium" : (x.priority === "Review" ? "Info" : (x.priority || "Info"));
      var attr = x.trip_id ? ' data-trip="' + esc(x.trip_id) + '"' : (x.id ? ' data-task="' + esc(x.id) + '"' : "");
      var when = x.due_at ? fmtTime(x.due_at) : (x.sub || "");
      return '<div class="ops-qitem"' + attr + ' role="button" tabindex="0">' +
        '<div class="grow"><strong>' + esc(x.title) + '</strong><small>' + esc(when) + '</small></div>' +
        '<span class="pri ' + pri + '">' + esc(priLabel) + '</span></div>';
    }).join("") + '</div>';
  }

  function options(list, val, all) {
    return '<option value="">' + esc(all) + '</option>' + list.map(function (o) {
      return '<option value="' + esc(o.id) + '"' + (val === o.id ? " selected" : "") + '>' + esc(o.name) + '</option>';
    }).join("");
  }

  function unassignedTrips() {
    return trips.filter(function (t) {
      return !t.vessel_id && CLOSED.indexOf(t.raw.status) < 0 && t.raw.status !== "Cancelled";
    });
  }
  function tripOverlaps(a, b) {
    var aEnd = a.arriveTs || (a.departTs + 3600000), bEnd = b.arriveTs || (b.departTs + 3600000);
    return a.departTs < bEnd && b.departTs < aEnd;
  }
  function vesselSchedule(v, trip) {
    var onBoat = trips.filter(function (t) {
      return t.vessel_id === v.id && t.id !== trip.id && CLOSED.indexOf(t.raw.status) < 0 && t.raw.status !== "Cancelled";
    }).sort(function (a, b) { return a.departTs - b.departTs; });
    var clash = onBoat.some(function (t) { return tripOverlaps(t, trip); });
    var prev = null, next = null;
    onBoat.forEach(function (t) {
      if (t.departTs <= trip.departTs) prev = t;
      if (t.departTs > trip.departTs && !next) next = t;
    });
    var avail = v.status === "Out of service" || v.status === "Restricted" ? "maint" : (clash ? "busy" : "ok");
    return {
      avail: avail,
      label: avail === "ok" ? "Available" : avail === "busy" ? "Busy" : (v.status || "Unavailable"),
      last: prev ? prev.time : "—",
      next: next ? next.time : "—"
    };
  }
  function openAssign(tripId) {
    if (!canOps) return;
    var id = tripId;
    if (!id) {
      var list = unassignedTrips();
      if (!list.length) { boardToast("Every open trip already has a vessel."); return; }
      id = list[0].id;
    }
    var t = trips.filter(function (x) { return x.id === id; })[0];
    if (!t) return;
    assign = { tripId: id, vesselId: t.vessel_id || null, q: "" };
    paintAssign();
  }
  function closeAssign() {
    assign = null;
    var d = $("assignDrawer"), s = $("assignScrim");
    if (d) { d.hidden = true; d.innerHTML = ""; }
    if (s) s.hidden = true;
  }
  function paintAssign() {
    var d = $("assignDrawer"), s = $("assignScrim");
    if (!d || !s) return;
    if (!assign) { closeAssign(); return; }
    var t = trips.filter(function (x) { return x.id === assign.tripId; })[0];
    if (!t) { closeAssign(); return; }
    var dur = tripDuration(t);
    var qv = (assign.q || "").toLowerCase();
    var list = (vessels || []).filter(function (v) {
      if (!qv) return true;
      return (v.name + " " + (v.code || "") + " " + (v.kind || "")).toLowerCase().indexOf(qv) >= 0;
    });
    var openOnes = unassignedTrips();
    d.hidden = false; s.hidden = false;
    d.innerHTML =
      '<header class="av-head">' +
        '<div><h2>Assign Vessel</h2><p class="note">Pick a boat for this sailing</p></div>' +
        '<button type="button" class="td-close" id="avClose" aria-label="Close">' + icon(I.close) + '</button>' +
      '</header>' +
      '<div class="av-trip">' +
        '<strong>' + esc(t.time) + '</strong>' +
        '<span>' + esc(dayPretty(t.day)) + '</span>' +
        '<span class="av-route">' + esc(t.origin || "Origin") + ' → ' + esc(t.destination || "Destination") + '</span>' +
        (dur != null ? '<span>' + dur + ' min</span>' : "") +
        '<span class="av-code">' + esc(t.code || "") + '</span>' +
      '</div>' +
      (openOnes.length > 1
        ? '<div class="av-switch"><label>Trip</label><select id="avTrip">' +
            openOnes.concat(t.vessel_id ? [t] : []).filter(function (x, i, a) { return a.findIndex(function (y) { return y.id === x.id; }) === i; })
              .map(function (x) {
                return '<option value="' + esc(x.id) + '"' + (x.id === t.id ? " selected" : "") + '>' +
                  esc((x.code || "Trip") + " · " + x.time + " · " + (x.origin || "") + " → " + (x.destination || "")) + '</option>';
              }).join("") +
          '</select></div>'
        : "") +
      '<div class="av-search"><label class="fsearch">' + icon(I.search) +
        '<input type="search" id="avQ" placeholder="Search vessel…" value="' + esc(assign.q || "") + '" aria-label="Search vessel"></label></div>' +
      '<div class="av-list">' +
        (list.length ? list.map(function (v) {
          var sch = vesselSchedule(v, t);
          var cap = v.passenger_capacity != null ? (v.passenger_capacity + " pax") : "—";
          var on = assign.vesselId === v.id;
          var tight = t.booked != null && v.passenger_capacity != null && Number(t.booked) > Number(v.passenger_capacity);
          return '<button type="button" class="av-card' + (on ? " on" : "") + (sch.avail !== "ok" ? " dim" : "") + '" data-pick="' + esc(v.id) + '">' +
            '<span class="av-boat">' + icon(I.vessel) + '</span>' +
            '<span class="grow"><strong>' + esc(v.name) + '</strong>' +
              '<small>' + esc([v.kind || "Vessel", cap].join(" · ")) +
                (v.crew_capacity != null ? " · " + v.crew_capacity + " crew" : "") + '</small>' +
              '<span class="av-times">Last ' + esc(sch.last) + ' · Next ' + esc(sch.next) + '</span>' +
              (tight ? '<span class="av-warn">Booked seats exceed this vessel</span>' : "") +
            '</span>' +
            '<span class="av-badge av-' + sch.avail + '">' + esc(sch.label) + '</span>' +
            '<span class="av-radio" aria-hidden="true">' + (on ? icon(I.check) : "") + '</span>' +
          '</button>';
        }).join("") : '<p class="note" style="padding:12px">No vessels match.</p>') +
      '</div>' +
      '<footer class="av-foot">' +
        '<p class="av-hint">' + icon(I.alert) + ' This vessel will be assigned to <strong>' + esc(t.code || "this trip") + '</strong>.</p>' +
        '<div class="av-acts">' +
          '<button type="button" class="ghost" id="avCancel">Cancel</button>' +
          '<button type="button" class="save" id="avGo"' + (assign.vesselId ? "" : " disabled") + '>' + icon(I.check) + ' Assign Vessel</button>' +
        '</div>' +
      '</footer>';
    bindAssign();
  }
  function bindAssign() {
    if ($("avClose")) $("avClose").addEventListener("click", closeAssign);
    if ($("avCancel")) $("avCancel").addEventListener("click", closeAssign);
    if ($("assignScrim")) $("assignScrim").onclick = closeAssign;
    if ($("avQ")) $("avQ").addEventListener("input", function () {
      assign.q = $("avQ").value.trim();
      paintAssign();
      var i = $("avQ"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
    });
    if ($("avTrip")) $("avTrip").addEventListener("change", function () {
      assign.tripId = $("avTrip").value;
      var t = trips.filter(function (x) { return x.id === assign.tripId; })[0];
      assign.vesselId = (t && t.vessel_id) || null;
      paintAssign();
    });
    [].forEach.call(document.querySelectorAll("#assignDrawer [data-pick]"), function (b) {
      b.addEventListener("click", function () {
        assign.vesselId = b.dataset.pick;
        paintAssign();
      });
    });
    if ($("avGo")) $("avGo").addEventListener("click", function () {
      if (!assign || !assign.vesselId) return;
      var tid = assign.tripId, vid = assign.vesselId;
      var v = vessels.filter(function (x) { return x.id === vid; })[0];
      $("avGo").disabled = true;
      db.from("trips").update({ vessel_id: vid }).eq("id", tid).then(function (res) {
        if (res.error) { boardToast(res.error.message, true); paintAssign(); return; }
        closeAssign();
        boardToast((v && v.name ? v.name : "Vessel") + " assigned.");
        reload();
      });
    });
  }

  function render() {
    var k = kpis();
    var list = filtered();
    var statuses = ["Scheduled", "On time", "Boarding", "Delayed", "En Route", "Arrived", "Completed", "Cancelled"];
    var counts = tabCounts();
    var needVessel = unassignedTrips().length;

    $("opsActions").innerHTML = canOps
      ? '<button type="button" class="btn-soft" id="opsAssign">' + icon(I.vessel) + ' Assign vessel' +
          (needVessel ? '<b class="ops-act-badge">' + needVessel + '</b>' : "") + '</button>' +
        '<button type="button" class="primary-btn" id="opsNew">' + icon(I.plus) + ' New trip</button>'
      : "";

    $("ops").innerHTML =
      '<div class="ops-kpis">' +
        '<div class="ops-kpi"><span class="tile tone-blue">' + icon(I.vessel) + '</span><div><small>Active Trips</small><strong>' + k.active + '</strong><span class="sub">' + esc(k.activeHint) + '</span></div></div>' +
        '<div class="ops-kpi"><span class="tile tone-amber">' + icon(I.alert) + '</span><div><small>Delayed Trips</small><strong>' + k.delayed + '</strong><span class="sub">' + esc(k.delayedHint) + '</span></div></div>' +
        '<div class="ops-kpi"><span class="tile tone-teal">' + icon(I.boat) + '</span><div><small>Available Vessels</small><strong>' + k.vessels + '</strong><span class="sub">' + esc(k.vesselsHint) + '</span></div></div>' +
        '<div class="ops-kpi"><span class="tile tone-violet">' + icon(I.people) + '</span><div><small>Crew on Duty</small><strong>' + k.crew + '</strong><span class="sub">' + esc(k.crewHint) + '</span></div></div>' +
      '</div>' +
      '<div class="ops-layout">' +
        '<section class="ops-main">' +
          '<div class="card-head">' +
            '<div><h2>' + esc(boardTitle()) + '</h2>' +
              '<div class="ops-tabs seg">' +
                [["today", "Today"], ["upcoming", "Upcoming"], ["crew", "Crew"], ["completed", "Completed"], ["cancelled", "Cancelled"]].map(function (t) {
                  var n = counts[t[0]];
                  return '<button type="button" class="' + (tab === t[0] ? "on" : "") + '" data-tab="' + t[0] + '">' + t[1] + (n ? '<b class="' + (t[0] === "crew" ? "warn" : "") + '" title="' + (t[0] === "crew" ? "Trips still short of crew" : n + " trips") + '">' + n + '</b>' : "") + '</button>';
                }).join("") +
              '</div>' +
            '</div>' +
            '<div class="ops-head-acts">' +
              '<label class="ops-date"><input type="date" id="opsDay" value="' + esc(dayF) + '" aria-label="Filter by date"></label>' +
              (dayF ? '<button type="button" class="btn-soft" id="clearDayTop">Clear</button>' : "") +
            '</div>' +
          '</div>' +
          (tab === "crew" ? "" :
            '<div class="ops-filters">' +
              '<select id="opsRoute" aria-label="Routes">' + options(routes, routeF, "All routes") + '</select>' +
              '<select id="opsVessel" aria-label="Vessels">' + options(vessels, vesselF, "All vessels") + '</select>' +
              '<select id="opsStatus" aria-label="Statuses"><option value="">All statuses</option>' +
                statuses.map(function (s) { return '<option value="' + esc(s) + '"' + (statusF === s ? " selected" : "") + '>' + esc(s) + '</option>'; }).join("") +
              '</select>' +
              '<label class="fsearch">' + icon(I.search) + '<input type="search" id="opsQ" placeholder="Find a trip" value="' + esc(q) + '" aria-label="Find a trip"></label>' +
            '</div>') +
          (tab === "crew" ? "" : liveStrip()) +
          (tab === "crew" ? crewBoard() : (list.length ? listByDay(list) : emptyBoard())) +
        '</section>' +
      '</div>';

    bind();
    if (assign) paintAssign();
    else closeAssign();
  }

  function loadData() {
    var today = todayIso();
    var from = new Date(addDays(today, -14) + "T00:00:00"), to = new Date(addDays(today, 32) + "T00:00:00");
    // Don't block the board on scan_operations — it can run slowly; cron already covers most of it.
    rpc("scan_operations", { p_company: company.id }).then(function () {}, function () {});
    return Promise.all([
      rpc("ops_board", { p_company: company.id, p_day: today }),
      rpc("schedule_trips", { p_company: company.id, p_from: from.toISOString(), p_to: to.toISOString() }),
      db.from("routes").select("id,name,duration_min").eq("company_id", company.id).eq("active", true).order("name"),
      db.from("vessels").select("id,name,code,kind,status,passenger_capacity,crew_capacity,meta").eq("company_id", company.id).order("name")
    ]).then(function (res) {
      var board = res[0] || {};
      kp = board.kpis || null;
      queue = board.queue || [];
      trips = ((res[1] || {}).trips || []).map(view);
      if (res[2].error) throw new Error(res[2].error.message);
      if (res[3].error) throw new Error(res[3].error.message);
      routes = res[2].data || [];
      vessels = res[3].data || [];
      return db.from("company_members").select("user_id").eq("company_id", company.id).eq("active", true).eq("employment_status", "Active");
    }).then(function (m) {
      if (m && m.error) { staff = []; return; }
      var ids = ((m && m.data) || []).map(function (x) { return x.user_id; });
      if (!ids.length) { staff = []; return; }
      return db.from("profiles").select("id, full_name, email").in("id", ids).then(function (p) {
        staff = (p.data || []).map(function (x) { return { id: x.id, name: x.full_name || (x.email || "").split("@")[0] || "Staff" }; })
          .sort(function (a, b) { return a.name.localeCompare(b.name); });
      });
    });
  }

  function reload() {
    return loadData().then(function () {
      try { render(); } catch (e) {
        $("ops").innerHTML = '<section class="dash-card"><h2>Could not load Operations</h2><p class="note">' + esc((e && e.message) || String(e)) + '</p></section>';
      }
    }, function (err) {
      $("ops").innerHTML = '<section class="dash-card"><h2>Could not load Operations</h2><p class="note">' + esc(err.message) + '</p></section>';
    });
  }

  function openNewTrip() {
    if (!routes.length) {
      openModal('<h2>New trip</h2><p class="note">Add a route first. Routes are set up under <a href="schedules.html">Schedules</a>.</p>' +
        '<div class="modal-actions"><button type="button" class="ghost" data-close>Close</button></div>');
      return;
    }
    openModal('<h2>New trip</h2><p class="note">Add a one-off sailing to the dispatch board. Recurring Fixed / Promotional / Temporary timetables live under <a href="schedules.html">Schedules</a>.</p>' +
      '<div class="cards">' +
        '<div class="fld"><label for="tDay">Date</label><input id="tDay" type="date" value="' + esc(todayIso()) + '"></div>' +
        '<div class="fld"><label for="tTime">Departure</label><input id="tTime" type="time" value="14:30"></div>' +
        '<div class="fld"><label for="tRoute">Route</label><select id="tRoute">' + options(routes, "", "Choose a route") + '</select></div>' +
        '<div class="fld"><label for="tVessel">Vessel</label><select id="tVessel">' +
          options(vessels.filter(function (v) { return v.status !== "Out of service"; }), "", "No vessel yet") + '</select></div>' +
      '</div>' +
      '<p class="msg" id="mMsg" role="status"></p>' +
      '<div class="modal-actions"><button type="button" class="ghost" data-close>Cancel</button><button type="button" class="save" id="tGo">Create trip</button></div>');
    $("tGo").addEventListener("click", function () {
      if (!$("tDay").value || !$("tTime").value || !$("tRoute").value) {
        say("Enter date, departure time and route.", "err"); return;
      }
      var dep = new Date($("tDay").value + "T" + $("tTime").value + ":00");
      $("tGo").disabled = true; say("Saving…");
      db.from("trips").insert({
        company_id: company.id, route_id: $("tRoute").value, vessel_id: $("tVessel").value || null,
        depart_at: dep.toISOString()
      }).select("code").single().then(function (r) {
        if (r.error) { $("tGo").disabled = false; say(r.error.message, "err"); return; }
        closeModal();
        tab = iso(dep) === todayIso() ? "today" : "upcoming";
        reload();
      });
    });
  }

  // Trip detail view: Overview (assign, clear, status), Passengers (manifest, check-in, boarding, manual booking),
  // Crew (captain + crew, roster auto-assign) and History (trip_events). Data: trip_manifest, trip_crew, trip_events.
  // Cursor 2026-10-23: passenger board uses paxSort / paxView for sort + density.
  var detail = { id: null, tab: "overview", man: null, crew: [], events: [], addPax: false, paxId: null, paxExtra: null, track: null, paxF: "all", paxQ: "", paxSort: "name", paxView: "cards" };
  var trackMap = null, trackTimer = null;

  function soft(p, fallback, ms) {
    var done = Promise.resolve(p).then(function (v) { return v; }, function () { return fallback; });
    if (!ms) return done;
    return Promise.race([
      done,
      new Promise(function (resolve) { setTimeout(function () { resolve(fallback); }, ms); })
    ]);
  }
  function loadDetail(id) {
    // Soft + timed: hung trip_manifest must not leave the modal on “Loading…”.
    return Promise.all([
      soft(rpc("trip_manifest", { p_trip: id }), null, 8000),
      soft(db.from("trip_crew").select("user_id, role, meta").eq("trip_id", id), { data: [] }, 8000),
      soft(db.from("trip_events").select("kind, detail, created_at").eq("trip_id", id).order("created_at", { ascending: false }).limit(60), { data: [] }, 8000)
    ]).then(function (res) {
      var man = res[0];
      detail.man = man && typeof man === "object"
        ? { passengers: man.passengers || [], counts: man.counts || {}, sellable: man.sellable, seats_booked: man.seats_booked }
        : { passengers: [], counts: {}, _err: true };
      detail.crew = (res[1] && !res[1].error && res[1].data) || [];
      detail.events = (res[2] && !res[2].error && res[2].data) || [];
    });
  }

  function openTrip(id, tabSel) {
    detail.id = id; detail.tab = tabSel || "overview"; detail.addPax = false;
    detail.paxId = null; detail.paxExtra = null;
    detail.track = null;
    destroyTrackMap();
    if (!trips.some(function (x) { return x.id === id; })) return;
    // Paint the trip shell immediately from board data; enrich when detail RPCs return.
    detail.man = { passengers: [], counts: {}, _loading: true };
    detail.crew = [];
    detail.events = [];
    try { renderTrip(); } catch (e) {
      openModal('<p class="msg err">' + esc((e && e.message) || "Could not open this trip.") + '</p><div class="modal-actions"><button type="button" class="ghost" data-close>Close</button></div>');
      return;
    }
    loadDetail(id).then(function () {
      if (detail.id !== id || $("modal").hidden) return;
      try { renderTrip(); } catch (e) { say((e && e.message) || "Could not refresh trip.", "err"); }
    }, function (e) {
      if (detail.id !== id || $("modal").hidden) return;
      detail.man = { passengers: [], counts: {}, _err: true };
      try { renderTrip(); } catch (err) {}
      say((e && e.message) || "Some trip details could not load.", "err");
    });
  }

  function staffName(uid) { var s = staff.filter(function (x) { return x.id === uid; })[0]; return s ? s.name : "Staff member"; }
  function fmtTime(ts) { var d = new Date(ts); return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()); }
  function listSetting(key, def) {
    var v = company && company.settings ? company.settings[key] : null;
    var rows = Array.isArray(v) ? v : def;
    return rows.map(function (r) { return typeof r === "string" ? r : r && r.name; }).filter(Boolean);
  }
  // Cursor 2026-10-24: money + methods from Finance Settings (9_base_currency / 9_payment_methods / 9_supported_currencies).
  function baseCurrency() {
    var s = company && company.settings ? company.settings["9_base_currency"] : null;
    var code = (s && typeof s === "object" && s.base) || (company && company.currency) || "MVR";
    var dec = s && typeof s === "object" && Number(s.decimals) >= 0 ? Number(s.decimals) : 2;
    return { code: String(code || "MVR"), dec: Math.min(4, Math.max(0, dec)) };
  }
  function payMethods() {
    var m = listSetting("9_payment_methods", ["Cash", "Card", "Bank transfer", "Mobile wallet", "Invoice"]);
    return m.length ? m : ["Cash", "Card", "Bank transfer", "Mobile wallet", "Invoice"];
  }
  function acceptedCurrencies() {
    var base = baseCurrency().code;
    var list = listSetting("9_supported_currencies", [base]);
    if (list.indexOf(base) < 0) list = [base].concat(list);
    return list.length ? list : [base];
  }
  function fmtMoney(n) {
    var c = baseCurrency(), x = Number(n) || 0;
    return c.code + " " + x.toLocaleString(undefined, { minimumFractionDigits: c.dec, maximumFractionDigits: c.dec });
  }
  function payMethodsHtml(selected) {
    var methods = payMethods(), cur = selected || methods[0] || "Cash";
    if (methods.indexOf(cur) < 0) cur = methods[0] || "Cash";
    return methods.map(function (x) { return '<option' + (x === cur ? " selected" : "") + '>' + esc(x) + '</option>'; }).join("");
  }
  function payCurrencyNote() {
    var cur = acceptedCurrencies(), base = baseCurrency().code;
    if (cur.length <= 1) return '<small class="plx-pay-cur">Amounts in ' + esc(base) + '</small>';
    return '<small class="plx-pay-cur">Amounts in ' + esc(base) + ' · Accepted: ' + esc(cur.join(", ")) + '</small>';
  }
  function tripDuration(t) {
    if (t.departTs && t.arriveTs) {
      var m0 = Math.round((t.arriveTs - t.departTs) / 60000);
      if (m0 > 0) return m0;
    }
    if (!t.raw || !t.raw.depart_at || !t.raw.arrive_at) return null;
    var m = Math.round((new Date(t.raw.arrive_at) - new Date(t.raw.depart_at)) / 60000);
    return m > 0 ? m : null;
  }
  function dayPretty(day) {
    try { return new Date(day + "T12:00:00").toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }); }
    catch (e) { return day; }
  }
  function loadPct(booked, total) {
    var p = seatPct(booked, total);
    return p == null ? 0 : p;
  }

  function progressBar(pct) {
    return '<span class="td-bar"><span style="width:' + Math.max(0, Math.min(100, pct || 0)) + '%"></span></span>';
  }

  function tripHero(t) {
    var r = t.raw || {}, st = statusLabel(t.status), tone = statusTone(t.status);
    var dep = r.actual_depart ? fmtTime(r.actual_depart).split(" ").pop() : t.time;
    var arr = r.actual_arrive ? fmtTime(r.actual_arrive).split(" ").pop() : (t.arrive || "—");
    var dur = tripDuration(t), now = Date.now(), p = progressOf(t);
    var when = r.status === "Cancelled" ? "Cancelled" : CLOSED.indexOf(r.status) >= 0 ? "Arrived " + arr
      : t.status === "En Route" ? "Under way · " + (p == null ? 0 : p) + "%" : t.departTs > now ? "Departs " + untilText(t.departTs - now) : "Due to leave";
    var pos = CLOSED.indexOf(r.status) >= 0 ? 100 : (p == null ? 0 : p);
    return '<header class="tdx-hero tone-' + tone + '">' +
      '<div class="tdx-hero-top">' +
        '<span class="tdx-code">' + icon(I.vessel) + esc(t.code || "Trip") + '</span>' + chip(st) +
        (r.status_reason ? '<span class="tdx-reason">' + icon(I.alert) + esc(r.status_reason) + '</span>' : "") +
        '<span class="tdx-tools"><button type="button" class="tdx-tool" data-print="manifest" title="Print manifest">' + icon(I.print) + '</button>' +
        '<button type="button" class="tdx-tool" data-close aria-label="Close">' + icon(I.close) + '</button></span>' +
      '</div>' +
      '<div class="tdx-journey">' +
        '<div class="tdx-end"><strong>' + esc(dep) + '</strong><span>' + esc(t.origin || "Origin") + '</span></div>' +
        '<div class="tdx-rail"><span class="tdx-rail-line"><span style="width:' + pos + '%"></span></span><i style="left:' + pos + '%">' + icon(I.boat) + '</i>' +
          '<em data-until="' + (t.departTs > now && CLOSED.indexOf(r.status) < 0 && r.status !== "Cancelled" ? t.departTs : "") + '" data-prefix="Departs ">' + esc(when) + '</em></div>' +
        '<div class="tdx-end right"><strong>' + esc(arr) + '</strong><span>' + esc(t.destination || "Destination") + '</span></div>' +
      '</div>' +
      '<div class="tdx-meta">' +
        '<span>' + icon(I.clock) + esc(dayPretty(t.day)) + (dur != null ? " · " + dur + " min" : "") + '</span>' +
        '<span>' + icon(I.vessel) + esc(t.vesselCode || t.vessel || "No vessel") + '</span>' +
        '<span>' + icon(I.person) + esc(t.captain ? "Capt. " + t.captain : "No captain") + '</span>' +
        (t.route ? '<span>' + icon(I.pin) + esc(t.route) + '</span>' : "") +
      '</div>' +
      stepper(t) +
    '</header>';
  }
  // Scheduled → Cleared → Boarding → Departed → Arrived, with the current step lit.
  function stepper(t) {
    var r = t.raw || {};
    if (r.status === "Cancelled") return "";
    var steps = ["Scheduled", "Cleared", "Boarding", "Departed", "Arrived"];
    var at = r.status === "Arrived" || r.status === "Completed" ? 4 : (r.status === "Departed" || r.status === "In transit") ? 3 : r.status === "Boarding" ? 2 : r.cleared_at ? 1 : 0;
    return '<ol class="tdx-steps">' + steps.map(function (x, k) {
      return '<li class="' + (k < at ? "done" : k === at ? "now" : "") + '"><span>' + (k < at ? icon(I.ok) : k + 1) + '</span>' + x + '</li>';
    }).join("") + '</ol>';
  }

  function dispatchBar(t, closed) {
    if (!canOps || closed) return "";
    var r = t.raw || {};
    var primary = "";
    if (!r.cleared_at) primary = '<button type="button" class="save" data-act="clear">Clear to sail</button>';
    else if (["Scheduled", "Delayed"].indexOf(r.status) >= 0) primary = '<button type="button" class="save" data-act="Boarding">Start boarding</button>';
    else if (r.status === "Boarding") primary = '<button type="button" class="save" data-act="Departed">Mark departed</button>';
    else if (["Departed", "In transit"].indexOf(r.status) >= 0) primary = '<button type="button" class="save" data-act="Arrived">Mark arrived</button>';
    return '<div class="td-actions td-actions-foot">' +
      (!r.cleared_at
        ? '<div class="tdx-checks">' +
            '<div class="tdx-checks-head"><strong>Before you clear to sail</strong><span class="tdx-checks-count" id="cCount">0 of 2 done</span></div>' +
            '<div class="tdx-checks-grid">' +
              '<label class="tdx-check"><input type="checkbox" id="cWeather"><span class="tdx-check-ic">' + icon('<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18Z"/>') + '</span>' +
                '<span class="grow"><strong>Weather checked</strong><small>Wind, waves and visibility are fine for this crossing</small></span><span class="tdx-tick">' + icon(I.ok) + '</span></label>' +
              '<label class="tdx-check"><input type="checkbox" id="cCheck"><span class="tdx-check-ic">' + icon(I.shield || '<path d="M12 3 4 6v6c0 4.5 3.3 7.8 8 9 4.7-1.2 8-4.5 8-9V6l-8-3Z"/>') + '</span>' +
                '<span class="grow"><strong>Safety done</strong><small>Life jackets, exits, fire kit and headcount checked</small></span><span class="tdx-tick">' + icon(I.ok) + '</span></label>' +
            '</div></div>' : "") +
      '<div class="td-actions-main">' +
        primary +
        (["Scheduled", "Delayed", "Boarding"].indexOf(r.status) >= 0 && r.cleared_at
          ? '<button type="button" class="btn-soft" data-act="Departed">Depart now</button>' : "") +
        (r.status !== "Delayed" ? '<button type="button" class="ghost" data-act="Delayed">Delay</button>' : "") +
        '<button type="button" class="ghost td-danger" data-act="Cancelled">Cancel</button>' +
      '</div>' +
      '<details class="tdx-why" id="cWhy"><summary><span class="tdx-why-ic">' + icon(I.alert) + '</span><span class="grow"><strong>Delay or cancel this trip</strong><small id="cWhyHint">Pick a reason first, then press Delay or Cancel</small></span><span class="tdx-why-chev">' + icon(I.chev) + '</span></summary>' +
        '<div class="tdx-why-body">' +
          '<div class="tdx-reasons" role="radiogroup" aria-label="Reason">' +
            listSetting("3_delay_reasons", ["Weather", "Technical fault", "Late crew", "Late passengers", "Port congestion", "Fuel delay", "Safety inspection", "Other"]).map(function (x) {
              return '<button type="button" class="tdx-reason" role="radio" aria-checked="false" data-reason="' + esc(x) + '">' + esc(x) + '</button>';
            }).join("") +
          '</div>' +
          '<select id="cReason" aria-label="Reason" hidden><option value=""></option>' +
            listSetting("3_delay_reasons", ["Weather", "Technical fault", "Late crew", "Late passengers", "Port congestion", "Fuel delay", "Safety inspection", "Other"]).map(function (x) {
              return '<option>' + esc(x) + '</option>';
            }).join("") +
          '</select>' +
          '<label class="tdx-why-other">' + icon('<path d="M4 20h4L18 10l-4-4L4 16v4ZM14 6l4 4"/>') + '<input id="cReasonOther" maxlength="200" placeholder="Or type your own reason (passengers see it)"></label>' +
        '</div></details>' +
    '</div>';
  }

  function kpi(label, value, tip, ic, tone) {
    return '<div class="td-kpi' + (tone ? " tone-" + tone : "") + '"' + (tip ? ' title="' + esc(tip) + '"' : "") + '>' + (ic ? '<span class="tdx-kic">' + icon(ic) + '</span>' : "") + '<span><small>' + esc(label) + '</small><strong>' + esc(String(value)) + '</strong></span></div>';
  }
  // Seats by role from the vessel's crew needs, filled from the captain and trip_crew.
  function crewSeats(t) {
    var mix = mixOf(t); if (!mix.length) return "";
    var pool = (detail.crew || []).map(function (x) { return { name: staffName(x.user_id), role: x.role }; });
    return '<div class="ops-seats tdx-seats">' + mix.map(function (m) {
      var role = String(m.role), n = Number(m.n) || 0, out = [], isCapt = /^(captain|master|skipper)s?$/i.test(role.trim());
      for (var k = 0; k < n; k++) {
        var who = null;
        if (isCapt && k === 0 && t.captain) who = { name: t.captain };
        else { var ix = -1; pool.forEach(function (c, j) { if (ix < 0 && String(c.role || "").toLowerCase() === role.toLowerCase()) ix = j; }); if (ix > -1) who = pool.splice(ix, 1)[0]; }
        out.push(who ? '<span class="ops-seat on r-' + slug(role) + '" title="' + esc(who.name + " · " + role) + '"><b>' + esc(initials(who.name)) + '</b><small>' + esc(String(who.name).split(/\s+/)[0]) + '</small><em>' + esc(role) + '</em></span>'
          : '<span class="ops-seat open" title="Needs a ' + esc(role) + '"><b>+</b><small>Open</small><em>' + esc(role) + '</em></span>');
      }
      return out.join("");
    }).join("") + '</div>';
  }

  function crewCards(t, closed) {
    var rows = [];
    if (t.captain) rows.push({ name: t.captain, role: "Captain", uid: null, isCapt: true });
    (detail.crew || []).forEach(function (x) { rows.push({ name: staffName(x.user_id), role: x.role, uid: x.user_id, auto: x.meta && x.meta.auto }); });
    if (!rows.length) return '<p class="note">No crew assigned yet.</p>';
    var roles = ["Crew", "Cashier", "Deck", "Engineering", "Cabin"];
    return '<ul class="td-people">' + rows.map(function (x) {
      return '<li>' +
        '<span class="av r-' + slug(x.role) + '">' + esc(initials(x.name)) + '</span>' +
        '<div class="grow"><strong>' + esc(x.name) + '</strong>' +
          (canOps && !closed && x.uid
            ? '<select class="td-role-sel" data-role-user="' + esc(x.uid) + '" aria-label="Role">' +
                roles.map(function (role) { return '<option' + (x.role === role ? " selected" : "") + '>' + role + '</option>'; }).join("") +
                (roles.indexOf(x.role) < 0 ? '<option selected>' + esc(x.role) + '</option>' : "") +
              '</select>'
            : '<small>' + esc(x.role + (x.auto ? " · roster" : "")) + '</small>') +
        '</div>' +
        (x.isCapt ? '<span class="chip st-on-time">Captain</span>' : "") +
        (canOps && !closed && x.uid ? '<button type="button" class="ghost" data-uncrew="' + esc(x.uid) + '">Remove</button>' : "") +
      '</li>';
    }).join("") + '</ul>';
  }

  function payChip(status) {
    var s = status || "Unpaid";
    var cls = s === "Paid" || s === "Confirmed" ? "st-on-time"
      : s === "Partly paid" || s === "Refund due" ? "st-delayed"
      : s === "Refunded" || s === "Cancelled" ? "st-cancelled"
      : "st-scheduled";
    return chip(s, cls);
  }
  function paxTable(pax, closed) {
    if (!pax.length) return '<p class="note">No passengers booked yet. Use <strong>Add new passenger</strong> to book someone.</p>';
    return '<div class="td-table-wrap"><table class="td-table"><thead><tr>' +
      '<th>Passenger</th><th>Ticket</th><th>Payment</th><th>Status</th><th></th>' +
      '</tr></thead><tbody>' + pax.map(function (p) {
        var gone = p.status === "Cancelled" || p.booking_status === "Cancelled" || p.booking_status === "Refunded";
        var phone = p.phone || p.contact_phone || "";
        var pay = gone ? (p.booking_status === "Refunded" ? "Refunded" : "Cancelled") : (p.payment_status || "Unpaid");
        return '<tr class="' + (gone ? "gone" : "") + '">' +
          '<td><strong>' + esc(p.full_name) + '</strong>' +
            '<small class="td-subline">' + esc([p.category || "Adult", phone].filter(Boolean).join(" · ")) + '</small></td>' +
          '<td>' + esc(p.reference || "—") + '</td>' +
          '<td>' + payChip(pay) + '</td>' +
          '<td>' + chip(gone ? "Cancelled" : p.status) + '</td>' +
          '<td class="td-row-acts">' + (gone || closed ? "" :
            (p.status === "Booked" ? '<button type="button" class="btn-soft" data-pax="' + esc(p.id) + '" data-st="Checked in">Check in</button>' : "") +
            (p.status !== "Boarded" && p.status !== "Cancelled" ? '<button type="button" class="btn-soft" data-pax="' + esc(p.id) + '" data-st="Boarded">Board</button>' : "") +
            '<button type="button" class="ghost" data-cancelbk="' + esc(p.booking_id) + '">Cancel</button>') +
          '</td></tr>';
      }).join("") + '</tbody></table></div>';
  }

  /* ---------- trip window tab helpers (modern layout) ---------- */
  // Cursor 2026-10-23: live boarding board — hero KPIs, sort/density, stepper cards.
  var PAX_FILTERS = [["all", "All"], ["Booked", "Booked"], ["Checked in", "Checked in"], ["Boarded", "Boarded"], ["No-show", "No-show"], ["Cancelled", "Cancelled"]];
  var PAX_FLOW = { Booked: 0, "Checked in": 1, Boarded: 2, "No-show": 3, Cancelled: 4 };
  function paxGone(p) { return p.status === "Cancelled" || p.booking_status === "Cancelled" || p.booking_status === "Refunded"; }
  function paxState(p) { return paxGone(p) ? "Cancelled" : (p.status || "Booked"); }
  function paxStepIdx(st) {
    if (st === "Boarded") return 2;
    if (st === "Checked in") return 1;
    if (st === "Booked") return 0;
    return -1;
  }
  function paxStepper(st, compact) {
    if (st === "Cancelled" || st === "No-show") {
      return '<div class="plx-step bad' + (compact ? " sm" : "") + '"><span class="plx-step-dot">' + icon(I.close) + '</span><span>' + esc(st) + '</span></div>';
    }
    var cur = paxStepIdx(st), labels = ["Booked", "Checked in", "Boarded"];
    return '<ol class="plx-stepper' + (compact ? " sm" : "") + '" aria-label="Boarding progress">' + labels.map(function (lab, i) {
      var cls = i < cur ? "done" : i === cur ? "now" : "";
      return '<li class="' + cls + '"><i></i>' + (compact ? "" : '<span>' + lab + '</span>') + '</li>';
    }).join("") + '</ol>';
  }
  function paxCounts(list) {
    var cnt = { all: list.length, Booked: 0, "Checked in": 0, Boarded: 0, "No-show": 0, Cancelled: 0 };
    list.forEach(function (p) { var k = paxState(p); cnt[k] = (cnt[k] || 0) + 1; });
    return cnt;
  }
  function paxRing(boarded, total) {
    var t = Math.max(0, Number(total) || 0), b = Math.max(0, Number(boarded) || 0);
    var pct = t ? Math.min(100, Math.round(b * 100 / t)) : 0;
    var r = 42, circ = 2 * Math.PI * r, dash = (pct / 100) * circ;
    return '<div class="plx-ring" style="--pct:' + pct + '" aria-hidden="true">' +
      '<svg viewBox="0 0 100 100"><circle class="trk" cx="50" cy="50" r="' + r + '"/><circle class="val" cx="50" cy="50" r="' + r + '" stroke-dasharray="' + dash.toFixed(1) + ' ' + circ.toFixed(1) + '"/></svg>' +
      '<div class="plx-ring-txt"><strong>' + pct + '%</strong><small>boarded</small></div></div>';
  }
  function paxBoardHero(list, c, trip) {
    var cnt = paxCounts(list), f = detail.paxF || "all";
    var booked = c.booked != null ? c.booked : cnt.all;
    var boarded = c.boarded != null ? c.boarded : (cnt.Boarded || 0);
    var chk = c.checked_in != null ? c.checked_in : (cnt["Checked in"] || 0);
    var cap = trip && trip.capacity != null ? Number(trip.capacity) : null;
    var fillPct = cap && cap > 0 ? Math.min(100, Math.round((booked || 0) * 100 / cap)) : null;
    var primary = [["all", "All", cnt.all, "all"], ["Booked", "Booked", cnt.Booked || 0, "booked"], ["Checked in", "Checked in", cnt["Checked in"] || 0, "chk"], ["Boarded", "Boarded", cnt.Boarded || 0, "brd"]];
    var secondary = [["No-show", "No-show", cnt["No-show"] || 0], ["Cancelled", "Cancelled", cnt.Cancelled || 0]].filter(function (x) { return x[2] > 0; });
    return '<section class="plx-hero">' +
      '<div class="plx-hero-ring">' + paxRing(boarded, booked || 1) +
        '<div class="plx-hero-meta"><strong>' + boarded + ' <span>of</span> ' + (booked || 0) + '</strong><small>Passengers boarded</small>' +
          (fillPct != null ? '<div class="plx-seatfill" title="Seat fill"><span style="width:' + fillPct + '%"></span></div><em>' + (booked || 0) + ' / ' + cap + ' seats filled · ' + fillPct + '%</em>' : "") +
        '</div></div>' +
      '<div class="plx-kpis">' + primary.map(function (x) {
        return '<button type="button" class="plx-kpi k-' + x[3] + ((f === x[0]) ? " on" : "") + '" data-pxf="' + esc(x[0]) + '"><small>' + esc(x[1]) + '</small><strong>' + x[2] + '</strong></button>';
      }).join("") + '</div>' +
      (secondary.length ? '<div class="plx-sec">' + secondary.map(function (x) {
        return '<button type="button" class="tdx-chip' + (f === x[0] ? " on" : "") + '" data-pxf="' + esc(x[0]) + '">' + esc(x[1]) + '<b>' + x[2] + '</b></button>';
      }).join("") + '</div>' : "") +
    '</section>';
  }
  function paxCommandBar(canAdd, closed, waiting) {
    var sort = detail.paxSort || "name", view = detail.paxView || "cards";
    return '<div class="plx-bar">' +
      '<label class="tdx-search plx-search">' + icon(I.search) + '<input id="pxQ" type="search" placeholder="Search name, booking, ID or phone" value="' + esc(detail.paxQ || "") + '" autocomplete="off"></label>' +
      '<div class="plx-bar-right">' +
        '<label class="plx-sort"><span>Sort</span><select id="pxSort">' +
          [['name', 'Name'], ['status', 'Status flow'], ['ref', 'Booking ref']].map(function (o) {
            return '<option value="' + o[0] + '"' + (sort === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
          }).join("") +
        '</select></label>' +
        '<div class="plx-density" role="group" aria-label="List density">' +
          '<button type="button" class="plx-den' + (view === "cards" ? " on" : "") + '" data-pxview="cards" title="Comfortable">' + icon(I.people) + '</button>' +
          '<button type="button" class="plx-den' + (view === "compact" ? " on" : "") + '" data-pxview="compact" title="Compact">' + icon('<path d="M4 7h16M4 12h16M4 17h16"/>') + '</button>' +
        '</div>' +
        (canOps && !closed && waiting ? '<button type="button" class="btn-soft tdx-bulk" id="pxCheckAll">' + icon(I.ok) + ' Check in all ' + waiting + '</button>' : "") +
        (canAdd
          ? (detail.addPax
            ? '<button type="button" class="ghost" id="bAddCancel">Cancel</button>'
            : '<button type="button" class="primary-btn" id="bAddOpen">' + icon(I.plus) + ' Add passenger</button>')
          : "") +
      '</div></div>';
  }
  function paxSkeleton() {
    return '<div class="plx-list skel" aria-busy="true">' +
      [0, 1, 2, 3, 4].map(function (i) {
        return '<div class="plx-skel" style="--i:' + i + '"><span class="av"></span><span class="ln w60"></span><span class="ln w40"></span><span class="pill"></span></div>';
      }).join("") +
    '</div>';
  }
  // Seat map: one dot per seat — boarded, checked in, booked, free.
  function seatMap(t, c) {
    var cap = Number(t.capacity) || 0, boarded = c.boarded || 0, chk = c.checked_in || 0, booked = Math.max(0, (c.booked || 0) - boarded - chk);
    if (!cap) return '<p class="note">Assign a vessel to see its seats.</p>';
    var out = [];
    for (var i = 0; i < cap; i++) out.push('<i class="tdx-dot ' + (i < boarded ? "b" : i < boarded + chk ? "c" : i < boarded + chk + booked ? "k" : "f") + '" style="animation-delay:' + Math.min(i * 8, 400) + 'ms"></i>');
    return '<div class="tdx-seatmap" style="--cols:' + (cap > 40 ? 12 : cap > 20 ? 10 : 8) + '">' + out.join("") + '</div>' +
      '<div class="tdx-legend"><span><i class="tdx-dot b"></i>Boarded ' + boarded + '</span><span><i class="tdx-dot c"></i>Checked in ' + chk + '</span><span><i class="tdx-dot k"></i>Booked ' + booked + '</span><span><i class="tdx-dot f"></i>Free ' + Math.max(0, cap - (c.booked || 0)) + '</span></div>';
  }
  function boardingFunnel(c) {
    var total = Math.max(1, c.booked || 0), steps = [["Booked", c.booked || 0, "k"], ["Checked in", (c.checked_in || 0) + (c.boarded || 0), "c"], ["Boarded", c.boarded || 0, "b"]];
    return '<div class="tdx-funnel">' + steps.map(function (s) {
      var pct = Math.round(s[1] * 100 / total);
      return '<div class="tdx-funnel-row"><span class="lbl">' + s[0] + '</span><span class="tdx-funnel-bar"><span class="' + s[2] + '" style="width:' + (c.booked ? pct : 0) + '%"></span></span><strong>' + s[1] + '</strong></div>';
    }).join("") + '</div>';
  }
  function eventKind(e) {
    var d = String(e.detail || "").toLowerCase();
    if (e.kind === "status" || /→|departed|arrived|boarding|delay|cancel/.test(d)) return "status";
    if (/captain|crew|cashier|roster/.test(d)) return "crew";
    if (/booking|passenger|refund|seat/.test(d) || e.kind === "booking") return "booking";
    if (e.kind === "auto") return "auto";
    if (e.kind === "created") return "created";
    return "other";
  }
  var LOG_ICONS = { status: I.arrow, crew: I.people, booking: I.person, auto: I.clock, created: I.plus, other: I.clock };
  function logItem(e) {
    var k = eventKind(e), d = new Date(e.created_at);
    return '<li class="k-' + k + '"><span class="tdx-log-ic">' + icon(LOG_ICONS[k]) + '</span><div class="grow"><strong>' + esc(e.detail || e.kind) + '</strong>' +
      '<small>' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + (e.kind === "auto" ? ' · <em>automatic</em>' : '') + '</small></div></li>';
  }
  function paxNeedsPay(p, payOverride) {
    if (paxGone(p) || p.booking_status === "Refunded") return false;
    var pay = payOverride || p.payment_status || "Unpaid";
    return pay === "Unpaid" || pay === "Partly paid" || pay === "Refund due";
  }
  // Cursor 2026-10-23: mark booking paid via update_booking (paid_amount → fare_total).
  function markBookingPaid(bookingId, method) {
    return soft(db.from("bookings").select("fare_total, paid_amount, payment_status, payment_method").eq("id", bookingId).maybeSingle(), { data: null }, 6000)
      .then(function (res) {
        var b = res && res.data;
        if (!b) throw new Error("Booking not found.");
        if (b.payment_status === "Paid" || b.payment_status === "Refunded") throw new Error("This booking is already " + String(b.payment_status).toLowerCase() + ".");
        var due = Number(b.fare_total) || 0;
        var patch = { paid_amount: due };
        var allowed = payMethods();
        var meth = method || b.payment_method || allowed[0] || "Cash";
        if (allowed.length && allowed.indexOf(meth) < 0) meth = allowed[0];
        if (meth) patch.payment_method = meth;
        return rpc("update_booking", { p_id: bookingId, p_patch: patch });
      });
  }
  // Cursor 2026-10-23: passenger card — identity / progress / pay+board footer (no detail needed for pay).
  function paxPayBlock(p, pay) {
    if (!canOps || !paxNeedsPay(p, pay)) {
      return '<div class="plx-c-paystat">' + payChip(pay) + '</div>';
    }
    return '<div class="plx-c-pay" data-stop-open>' +
      '<span class="plx-c-pay-lab">Payment</span>' +
      payCurrencyNote() +
      '<div class="plx-c-pay-row">' +
        '<select class="plx-list-meth" aria-label="Payment method">' + payMethodsHtml() + '</select>' +
        '<button type="button" class="plx-mark-paid" data-markpaid="' + esc(p.booking_id) + '">' +
          icon('<path d="M4 7h16v12H4zM4 11h16M8 15h3"/>') + '<span>Mark paid</span></button>' +
      '</div></div>';
  }
  function paxBoardBlock(p, closed) {
    var st = paxState(p), gone = st === "Cancelled" || st === "No-show";
    if (gone || closed || !canOps) return "";
    var primary = "";
    if (p.status === "Booked") {
      primary = '<button type="button" class="plx-c-btn chk" data-pax="' + esc(p.id) + '" data-st="Checked in">' + icon(I.ok) + '<span>Check in</span></button>';
    } else if (p.status !== "Boarded" && p.status !== "Cancelled") {
      primary = '<button type="button" class="plx-c-btn brd" data-pax="' + esc(p.id) + '" data-st="Boarded">' + icon(I.boat) + '<span>Board</span></button>';
    } else if (st === "Boarded") {
      primary = '<span class="plx-c-done">' + icon(I.ok) + ' On board</span>';
    }
    return '<div class="plx-c-board" data-stop-open>' +
      primary +
      '<button type="button" class="plx-c-btn ghost del" data-cancelbk="' + esc(p.booking_id) + '" title="Cancel booking">' + icon(I.close) + '<span>Cancel</span></button>' +
    '</div>';
  }
  function paxCard(p, closed, idx) {
    var st = paxState(p), gone = st === "Cancelled";
    var pay = gone ? (p.booking_status === "Refunded" ? "Refunded" : "Cancelled") : (p.payment_status || "Unpaid");
    var phone = p.phone || p.contact_phone || "";
    var compact = (detail.paxView || "cards") === "compact";
    var needPay = canOps && paxNeedsPay(p, pay);
    var boardHtml = paxBoardBlock(p, closed);
    var payHtml = paxPayBlock(p, pay);
    var hasFoot = !!(boardHtml || needPay || (canOps && !paxNeedsPay(p, pay)));
    return '<article class="plx-card s-' + slug(st) + (compact ? " compact" : "") + (needPay ? " needs-pay" : "") + (gone ? " is-gone" : "") + '" style="--i:' + (idx || 0) + '" data-pax-open="' + esc(p.id) + '" role="button" tabindex="0" title="View passenger details">' +
      '<div class="plx-c-top">' +
        '<span class="plx-av" aria-hidden="true">' + esc(initials(p.full_name)) + '</span>' +
        '<div class="plx-c-id">' +
          '<div class="plx-name"><strong>' + esc(p.full_name || "Passenger") + '</strong><span class="plx-cat">' + esc(p.category || "Adult") + '</span></div>' +
          '<div class="plx-c-meta">' +
            (phone ? '<span class="plx-meta-i">' + esc(phone) + '</span>' : "") +
            (p.id_number ? '<span class="plx-meta-i">ID ' + esc(p.id_number) + '</span>' : "") +
            (!phone && !p.id_number ? '<span class="plx-meta-i muted">Tap for full details</span>' : "") +
          '</div>' +
        '</div>' +
        '<div class="plx-c-tags">' +
          '<span class="tdx-pill s-' + slug(st) + '">' + esc(st) + '</span>' +
          (!needPay ? payChip(pay) : '<span class="chip st-delayed">' + esc(pay) + '</span>') +
        '</div>' +
      '</div>' +
      '<div class="plx-c-mid">' +
        '<div class="plx-c-chips">' +
          '<span class="plx-chip ref" title="Booking reference">' + esc(p.reference || "—") + '</span>' +
          (p.seat_no ? '<span class="plx-chip seat">Seat ' + esc(p.seat_no) + '</span>' : '<span class="plx-chip muted">No seat</span>') +
          (p.source ? '<span class="plx-chip src">' + esc(p.source) + '</span>' : "") +
        '</div>' +
        (compact ? "" : '<div class="plx-c-progress">' + paxStepper(st, false) + '</div>') +
      '</div>' +
      (hasFoot
        ? '<div class="plx-c-foot" data-stop-open>' + payHtml + boardHtml + '</div>'
        : "") +
      '<span class="plx-c-open" aria-hidden="true">' + icon(I.chev) + '</span>' +
    '</article>';
  }

  function fmtWhen(iso) {
    if (!iso) return "";
    try {
      var d = new Date(iso);
      if (isNaN(d.getTime())) return String(iso);
      return pad2(d.getDate()) + "/" + pad2(d.getMonth() + 1) + "/" + d.getFullYear() + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes());
    } catch (e) { return String(iso); }
  }
  // Cursor 2026-10-23: detail fields/panels — high contrast so sections don’t blend.
  function paxField(label, value, empty) {
    var blank = value == null || value === "";
    var v = blank ? "—" : String(value);
    return '<div class="plx-field' + (blank || empty ? " is-empty" : "") + '"><span class="plx-field-lab">' + esc(label) + '</span><strong class="plx-field-val">' + esc(v) + '</strong></div>';
  }
  function paxPanel(title, ico, bodyHtml, tone) {
    return '<section class="plx-panel' + (tone ? " t-" + tone : "") + '">' +
      '<header class="plx-panel-h">' +
        '<span class="plx-panel-ic" aria-hidden="true">' + icon(ico) + '</span>' +
        '<h3>' + title + '</h3>' +
      '</header>' +
      '<div class="plx-panel-b">' + bodyHtml + '</div>' +
    '</section>';
  }
  function paxDetailTimeline(p, st) {
    var steps = [
      { lab: "Booked", done: true, when: null },
      { lab: "Checked in", done: st === "Checked in" || st === "Boarded", when: p.checked_in_at },
      { lab: "Boarded", done: st === "Boarded", when: p.boarded_at }
    ];
    if (st === "Cancelled" || st === "No-show") {
      return '<div class="plx-tl bad"><span class="plx-tl-dot">' + icon(I.close) + '</span><div><strong>' + esc(st) + '</strong><small>This passenger is not boarding.</small></div></div>';
    }
    var doneN = steps.filter(function (x) { return x.done; }).length;
    return '<ol class="plx-tl" style="--steps:3;--done:' + Math.max(0, doneN - 1) + '">' + steps.map(function (s, i) {
      var cls = s.done ? (i === doneN - 1 ? "now" : "done") : "todo";
      return '<li class="' + cls + '"><span class="plx-tl-node"><i></i></span><div><strong>' + s.lab + '</strong><small>' + (s.when ? esc(fmtWhen(s.when)) : (s.done ? "Done" : "Pending")) + '</small></div></li>';
    }).join("") + '</ol>';
  }
  function paxDetailView(p, closed, trip) {
    var ex = detail.paxExtra || {};
    var st = paxState(p), gone = st === "Cancelled";
    var pay = gone ? (p.booking_status === "Refunded" ? "Refunded" : "Cancelled") : (ex.payment_status || p.payment_status || "Unpaid");
    var mobile = p.phone || ex.phone_registry || "";
    var contactPhone = ex.contact_phone || p.contact_phone || "";
    var phone = mobile || contactPhone || "";
    var fare = p.fare != null ? fmtMoney(p.fare) : null;
    var paid = ex.paid_amount != null ? fmtMoney(ex.paid_amount) : null;
    var total = ex.fare_total != null ? fmtMoney(ex.fare_total) : null;
    var route = trip ? ((trip.origin || "") + (trip.destination ? " → " + trip.destination : "")) : "";
    var ref = p.reference || ex.reference || "—";
    var needPay = canOps && !gone && paxNeedsPay(p, pay);
    var methods = payMethods();
    var curMeth = ex.payment_method || methods[0] || "Cash";
    if (methods.indexOf(curMeth) < 0) curMeth = methods[0] || "Cash";
    var acts =
      (needPay ? '<button type="button" class="save plx-pay-btn" data-markpaid="' + esc(p.booking_id) + '">' + icon('<path d="M4 7h16v12H4zM4 11h16M8 15h3"/>') + ' Mark as paid' + (total ? ' · ' + esc(total) : "") + '</button>' : "") +
      (gone || closed ? "" :
        (p.status === "Booked" ? '<button type="button" class="btn-soft" data-pax="' + esc(p.id) + '" data-st="Checked in">' + icon(I.ok) + ' Check in</button>' : "") +
        (p.status !== "Boarded" && p.status !== "Cancelled" ? '<button type="button" class="btn-soft" data-pax="' + esc(p.id) + '" data-st="Boarded">' + icon(I.boat) + ' Board</button>' : "") +
        '<button type="button" class="ghost td-danger" data-cancelbk="' + esc(p.booking_id) + '">Cancel booking</button>');
    return '<div class="plx-pd s-' + slug(st) + '">' +
      '<div class="plx-pd-bar">' +
        '<button type="button" class="plx-back" id="paxBack">' + icon(I.chev) + '<span>Back to list</span></button>' +
        '<div class="tdx-pd-acts plx-pd-acts">' + acts + '</div>' +
      '</div>' +
      '<header class="plx-pd-hero s-' + slug(st) + '">' +
        '<div class="plx-pd-band" aria-hidden="true"></div>' +
        '<div class="plx-pd-hero-in">' +
          '<span class="tdx-pax-av lg plx-av">' + esc(initials(p.full_name)) + '</span>' +
          '<div class="grow">' +
            '<p class="plx-pd-kicker">' + esc(ref) + (p.seat_no ? ' · Seat ' + esc(p.seat_no) : "") + '</p>' +
            '<strong>' + esc(p.full_name || "Passenger") + '</strong>' +
            '<small>' + esc([p.category || "Adult", phone || "No phone"].filter(Boolean).join(" · ")) + '</small>' +
          '</div>' +
          '<div class="tdx-pd-badges plx-pd-badges">' +
            '<span class="tdx-pill s-' + slug(st) + '">' + esc(st) + '</span>' +
            payChip(pay) +
          '</div>' +
        '</div>' +
      '</header>' +
      paxPanel("Boarding timeline", I.boat, paxDetailTimeline(p, st), "timeline") +
      (ex._loading ? '<p class="note plx-pd-note">Loading booking details…</p>' : "") +
      (ex._err ? '<p class="note td-err plx-pd-note">Some booking fields could not load.</p>' : "") +
      '<div class="plx-pd-cols">' +
        paxPanel("Passenger", I.person,
          '<div class="plx-fields">' +
            paxField("Full name", p.full_name) +
            paxField("Mobile number", mobile || contactPhone || null) +
            (mobile && contactPhone && mobile !== contactPhone ? paxField("Booking contact phone", contactPhone) : "") +
            paxField("Category", p.category || "Adult") +
            paxField("ID / passport", p.id_number) +
            paxField("Nationality", p.nationality || ex.nationality) +
            paxField("Email", ex.email || ex.contact_email) +
            paxField("Date of birth", ex.dob ? fmtWhen(ex.dob).split(" ")[0] : null) +
            paxField("Emergency contact", ex.emergency_contact) +
            paxField("Seat", p.seat_no) +
            paxField("Fare", fare) +
            paxField("Passenger note", ex.pax_note || (p.meta && p.meta.note)) +
          '</div>') +
        paxPanel("Trip & boarding", I.clock,
          '<div class="plx-fields">' +
            paxField("Status", st) +
            paxField("Checked in", p.checked_in_at ? fmtWhen(p.checked_in_at) : (st === "Checked in" || st === "Boarded" ? "Yes" : "Not yet")) +
            paxField("Boarded", p.boarded_at ? fmtWhen(p.boarded_at) : (st === "Boarded" ? "Yes" : "Not yet")) +
            paxField("Trip", trip ? (trip.code || "Trip") : null) +
            paxField("Route", route || null) +
            paxField("Departure", trip && trip.departTs ? fmtTime(trip.departTs) : (trip && trip.time)) +
          '</div>', "board") +
      '</div>' +
      paxPanel("Booking & payment", '<path d="M4 7h16v12H4zM4 11h16M8 15h3"/>',
        (needPay
          ? '<div class="plx-paybox">' +
              '<div class="plx-paybox-copy"><strong>Collect payment</strong><small>Sets paid amount to the fare total (' + esc(total || fmtMoney(0)) + ') and marks the booking Paid. Methods come from Finance Settings.</small>' + payCurrencyNote() + '</div>' +
              '<label class="plx-pay-meth"><span>Method</span><select id="pxPayMethod">' + payMethodsHtml(curMeth) + '</select></label>' +
              '<button type="button" class="save" data-markpaid="' + esc(p.booking_id) + '">' + icon('<path d="M4 7h16v12H4zM4 11h16M8 15h3"/>') + ' Mark as paid</button>' +
            '</div>'
          : (pay === "Paid" ? '<div class="plx-paybox is-paid"><strong>Paid in full</strong><small>' + esc(ex.payment_method || "Payment recorded") + (paid ? " · " + esc(paid) : "") + '</small></div>' : "")) +
        '<div class="plx-fields cols-3">' +
          paxField("Booking reference", ref) +
          paxField("Booking status", p.booking_status || ex.status) +
          paxField("Source", p.source || ex.source) +
          paxField("Contact name", ex.contact_name) +
          paxField("Contact phone", contactPhone || phone) +
          paxField("Contact email", ex.contact_email) +
          paxField("Ticket type", ex.ticket_type) +
          paxField("Payment status", pay) +
          paxField("Payment method", ex.payment_method) +
          paxField("Fare total", total) +
          paxField("Paid amount", paid) +
          paxField("Refund", ex.refund_amount != null ? fmtMoney(ex.refund_amount) : null) +
          paxField("Booked at", ex.created_at ? fmtWhen(ex.created_at) : null) +
          paxField("Cancel reason", ex.cancel_reason) +
          paxField("Booking note", ex.note) +
        '</div>', "pay") +
    '</div>';
  }

  function openPaxDetail(paxId) {
    detail.paxId = paxId;
    detail.addPax = false;
    detail.paxExtra = { _loading: true };
    var list = (detail.man && detail.man.passengers) || [];
    var p = list.filter(function (x) { return x.id === paxId; })[0];
    renderTrip();
    if (!p || !p.booking_id) {
      detail.paxExtra = { _loading: false };
      renderTrip();
      return;
    }
    var jobs = [
      soft(db.from("bookings").select("reference, status, source, contact_name, contact_phone, contact_email, ticket_type, fare_total, paid_amount, payment_method, payment_status, refund_amount, cancel_reason, cancelled_at, note, created_at").eq("id", p.booking_id).maybeSingle(), { data: null }, 6000)
    ];
    if (p.passenger_id) {
      jobs.push(soft(db.from("passengers").select("email, phone, nationality, dob, emergency_contact, note").eq("id", p.passenger_id).maybeSingle(), { data: null }, 6000));
    }
    Promise.all(jobs).then(function (res) {
      if (detail.paxId !== paxId) return;
      var b = res[0] && res[0].data ? res[0].data : null;
      var reg = res[1] && res[1].data ? res[1].data : null;
      detail.paxExtra = Object.assign({}, b || {}, {
        email: (reg && reg.email) || (b && b.contact_email) || null,
        nationality: (reg && reg.nationality) || null,
        dob: reg && reg.dob,
        emergency_contact: reg && reg.emergency_contact,
        pax_note: reg && reg.note,
        phone_registry: reg && reg.phone,
        _loading: false,
        _err: !b
      });
      renderTrip();
    }, function () {
      if (detail.paxId !== paxId) return;
      detail.paxExtra = { _loading: false, _err: true };
      renderTrip();
    });
  }
  function paxList(pax, closed) {
    if (!pax.length) return '<div class="tdx-empty">' + icon(I.people) + '<strong>No passengers yet</strong><small>Use <b>Add passenger</b> to make the first booking.</small></div>';
    var f = detail.paxF || "all", q = (detail.paxQ || "").toLowerCase(), sort = detail.paxSort || "name";
    var shown = pax.filter(function (p) {
      return (f === "all" || paxState(p) === f) && (!q || (p.full_name + " " + (p.reference || "") + " " + (p.id_number || "") + " " + (p.phone || p.contact_phone || "")).toLowerCase().indexOf(q) > -1);
    }).slice();
    shown.sort(function (a, b) {
      if (sort === "status") {
        var da = PAX_FLOW[paxState(a)] != null ? PAX_FLOW[paxState(a)] : 9;
        var dbv = PAX_FLOW[paxState(b)] != null ? PAX_FLOW[paxState(b)] : 9;
        if (da !== dbv) return da - dbv;
      } else if (sort === "ref") {
        var ra = String(a.reference || ""), rb = String(b.reference || "");
        if (ra !== rb) return ra < rb ? -1 : 1;
      }
      return String(a.full_name || "").localeCompare(String(b.full_name || ""));
    });
    var view = detail.paxView || "cards";
    return shown.length
      ? '<div class="tdx-pax-list plx-list' + (view === "compact" ? " is-compact" : "") + '">' + shown.map(function (p, i) { return paxCard(p, closed, i); }).join("") + '</div>'
      : '<div class="tdx-empty">' + icon(I.search) + '<strong>No one matches</strong><small>Try another filter or search.</small></div>';
  }

  function vesselMetaOf(v) {
    return v && v.meta && typeof v.meta === "object" && !Array.isArray(v.meta) ? v.meta : {};
  }
  function followmeLinked(v) {
    var m = vesselMetaOf(v);
    return !!(m.followme_set || m.followme_url || m.followme);
  }
  function followmeHintOf(v) {
    var m = vesselMetaOf(v);
    return String(m.followme_hint || "").trim();
  }
  function numOrNull(x) {
    if (x == null || x === "") return null;
    var n = Number(x);
    return isFinite(n) ? n : null;
  }
  function pickLatLng(o) {
    if (!o || typeof o !== "object") return null;
    var lat = numOrNull(o.lat != null ? o.lat : (o.la != null ? o.la : (o.latitude != null ? o.latitude : (o.Latitude != null ? o.Latitude : o.LAT))));
    var lng = numOrNull(o.lng != null ? o.lng : (o.lon != null ? o.lon : (o.lo != null ? o.lo : (o.longitude != null ? o.longitude : (o.Longitude != null ? o.Longitude : o.LONG)))));
    if (lat == null || lng == null) return null;
    if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
    return {
      lat: lat, lng: lng,
      name: o.name || o.Name || o.vessel || o.Vessel || "",
      speed: numOrNull(o.speed != null ? o.speed : (o.Speed != null ? o.Speed : (o["Speed(kn)"] != null ? o["Speed(kn)"] : o["speed_kn"]))),
      heading: numOrNull(o.heading != null ? o.heading : (o.course != null ? o.course : (o.Course != null ? o.Course : o.Heading))),
      port: o.port || o.Port || o.last_port || "",
      updated: o.updated || o.Updated || o.time || o.Time || o.date || o.Date || o.timestamp || ""
    };
  }
  function parseFollowmePayload(raw) {
    var text = typeof raw === "string" ? raw : JSON.stringify(raw);
    if (typeof raw === "string" && /<!doctype\s+html|<html[\s>]/i.test(raw) && !/"lat"\s*:|"latitude"\s*:|"la"\s*:/i.test(raw)) {
      return { error: "This vessel’s FollowMe link is a share page (HTML), not the API — no coordinates to plot. Re-save the vessel with https://followme.mv/api/v5/public/<key>/ (Fleet / Maintenance → Edit)." };
    }
    var data = raw;
    if (typeof raw === "string") {
      try {
        var m = raw.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
        data = JSON.parse(m ? m[0] : raw);
      } catch (e) { return { error: "FollowMe returned data that is not JSON." }; }
    }
    var items = [];
    if (Array.isArray(data)) items = data;
    else if (data && Array.isArray(data.data)) items = data.data;
    else if (data && data.data && typeof data.data === "object") {
      Object.keys(data.data).forEach(function (k) {
        var v = data.data[k];
        if (v && typeof v === "object") items.push(Object.assign({ id: k }, v));
      });
    } else if (data && typeof data === "object") {
      var one = pickLatLng(data);
      if (one) return { pos: one, count: 1 };
      Object.keys(data).forEach(function (k) {
        if (k === "data" || k === "status" || k === "message") return;
        var v = data[k];
        if (v && typeof v === "object") items.push(Object.assign({ id: k }, v));
      });
    }
    var found = null;
    items.forEach(function (it) { if (!found) found = pickLatLng(it); });
    if (found) return { pos: found, count: items.length };
    if (items.length) return { error: "FollowMe responded, but no latitude/longitude was found.", count: items.length, sample: items[0] };
    return { error: "No vessel position in the FollowMe response." };
  }
  function destroyTrackMap() {
    if (trackTimer) { clearInterval(trackTimer); trackTimer = null; }
    if (trackMap) { try { trackMap.remove(); } catch (e) {} trackMap = null; }
  }
  function clearTrackMapOnly() {
    if (trackMap) { try { trackMap.remove(); } catch (e) {} trackMap = null; }
  }
  function trackingView(t) {
    var v = vesselOf(t), linked = followmeLinked(v), hint = followmeHintOf(v) || (detail.track && detail.track.hint) || "";
    var tr = detail.track || { sub: "map" };
    var sub = tr.sub === "info" ? "info" : "map";
    if (!t.vessel_id) {
      return '<section class="td-block tdx-track"><div class="tdx-empty">' + icon(I.vessel) + '<strong>No vessel assigned</strong><small>Assign a vessel on Overview or Crew, then open Tracking again.</small></div></section>';
    }
    if (!linked) {
      return '<section class="td-block tdx-track"><div class="tdx-empty">' + icon(I.pin) + '<strong>No FollowMe link yet</strong><small>Add a followme.mv <em>API</em> URL on <a href="maintenance.html#vessel/' + esc(t.vessel_id) + '">this vessel</a> (e.g. https://followme.mv/api/v5/public/…/).</small></div></section>';
    }
    var pos = tr.pos, err = tr.err, loading = tr.loading, warn = tr.warning, nextIn = tr.next_in;
    var attr = tr.attribution || "FollowMe Tracking Service";
    var mini = '<div class="tdx-track-tabs" role="tablist">' +
      '<button type="button" class="' + (sub === "map" ? "on" : "") + '" data-track-sub="map">Map</button>' +
      '<button type="button" class="' + (sub === "info" ? "on" : "") + '" data-track-sub="info">Details</button>' +
    '</div>';
    var head = '<div class="tdx-track-head"><div><h3>Live tracking</h3><p class="note">' + esc(v ? (v.code || v.name) : "Vessel") +
      (pos && pos.name ? " · " + esc(pos.name) : "") +
      (hint ? " · " + esc(hint) : "") + '</p></div>' +
      '<div class="tdx-track-acts">' +
        '<button type="button" class="btn-soft" id="trRefresh"' + (loading ? " disabled" : "") + '>' + (loading ? "Refreshing…" : "Refresh") + '</button>' +
        '<a class="btn-soft" href="maintenance.html#vessel/' + esc(t.vessel_id) + '">Edit link</a>' +
      '</div></div>';
    var notes = (warn ? '<p class="note tdx-track-warn">' + esc(warn) + (nextIn ? " Next update in " + nextIn + "s." : "") + '</p>' : "") +
      (err ? '<p class="note td-err">' + esc(err) + '</p>' : "") +
      (nextIn && !warn ? '<p class="note">Next FollowMe update in ' + nextIn + "s.</p>" : "");
    var attrHtml = '<p class="tdx-track-attr"><img src="https://followme.mv/api/images/icon_50.png" alt=""> ' + esc(attr) + '</p>';
    if (sub === "info") {
      return '<section class="td-block tdx-track">' + head + mini + notes +
        '<div class="tdx-pd-grid">' +
          paxField("Vessel", v ? ((v.code ? v.code + " · " : "") + (v.name || "")) : "—") +
          paxField("FollowMe", hint || "Linked") +
          paxField("Latitude", pos ? pos.lat.toFixed(5) : null) +
          paxField("Longitude", pos ? pos.lng.toFixed(5) : null) +
          paxField("Speed", pos && pos.speed != null ? pos.speed + " kn" : null) +
          paxField("Heading", pos && pos.heading != null ? Math.round(pos.heading) + "°" : null) +
          paxField("Port / area", pos && pos.port ? pos.port : null) +
          paxField("Last update", pos && pos.updated ? String(pos.updated) : (tr.at ? new Date(tr.at).toLocaleString() : null)) +
        '</div>' + attrHtml +
      '</section>';
    }
    var waiting = loading || (!pos && !err && !tr.at);
    return '<section class="td-block tdx-track">' + head + mini + notes +
      (waiting && !pos ? '<p class="note">Fetching position from FollowMe…</p>' : "") +
      '<div class="tdx-track-map-wrap"><div id="tripTrackMap" class="tdx-track-map" aria-label="Vessel map"></div>' +
        (!pos && !waiting ? '<div class="tdx-track-overlay"><span><strong>Position unavailable</strong>' +
          esc(err || "Tap Refresh, or re-save this vessel with a FollowMe API URL (not the public share page).") +
          '</span></div>' : "") +
      '</div>' + attrHtml +
    '</section>';
  }
  function paintTrackMap() {
    clearTrackMapOnly();
    if (detail.tab !== "tracking" || (detail.track && detail.track.sub === "info")) return;
    var el = $("tripTrackMap");
    if (!el || !window.L) return;
    var pos = detail.track && detail.track.pos;
    var center = pos ? [pos.lat, pos.lng] : [4.25, 73.55];
    var zoom = pos ? 11 : 8;
    trackMap = L.map(el, { zoomControl: true, scrollWheelZoom: false, attributionControl: true }).setView(center, zoom);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "&copy; OpenStreetMap" }).addTo(trackMap);
    if (pos) {
      var heading = Number(pos.heading) || 0;
      var icon = L.divIcon({
        className: "tdx-vmark", iconSize: [30, 30], iconAnchor: [15, 15],
        html: '<svg viewBox="0 0 24 24" style="transform:rotate(' + heading + 'deg)"><path d="M12 2 19 21l-7-4-7 4z" fill="#1677e8" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>'
      });
      var tip = (pos.name || "Vessel") + (pos.speed != null ? " · " + Number(pos.speed).toFixed(1) + " kn" : "");
      L.marker([pos.lat, pos.lng], { icon: icon, title: tip }).bindPopup('<strong>' + esc(pos.name || "Vessel") + '</strong><br>' +
        pos.lat.toFixed(5) + ", " + pos.lng.toFixed(5) +
        (pos.speed != null ? "<br>" + Number(pos.speed).toFixed(1) + " kn" : "") +
        (pos.port ? "<br>" + esc(pos.port) : "")).addTo(trackMap);
    }
    setTimeout(function () { if (trackMap) trackMap.invalidateSize(); }, 80);
  }
  function applyTrackResult(t, keepSub, prevPos, meta, parsed) {
    if (detail.id !== t.id) return;
    var base = {
      sub: keepSub, loading: false, pos: (parsed && parsed.pos) || prevPos,
      err: (parsed && parsed.error && !(parsed && parsed.pos)) ? parsed.error : ((parsed && parsed.error) || null),
      at: meta.at ? new Date(meta.at).getTime() : Date.now(),
      hint: meta.hint || null, attribution: meta.attribution || null,
      warning: meta.warning || null, next_in: meta.next_in != null ? meta.next_in : null,
      stale: !!meta.stale, cached: !!meta.cached
    };
    detail.track = base;
    if (detail.tab === "tracking") renderTrip();
  }
  function loadTripTracking(force) {
    var t = trips.filter(function (x) { return x.id === detail.id; })[0];
    if (!t) return;
    var v = vesselOf(t);
    if (!followmeLinked(v)) { detail.track = { sub: (detail.track && detail.track.sub) || "map", err: null, loading: false }; return; }
    if (detail.track && detail.track.loading && !force) return;
    var now = Date.now();
    if (!force && detail.track && detail.track.at && (now - detail.track.at) < 55000 && (detail.track.pos || detail.track.err) && !detail.track.stale) return;
    var keepSub = (detail.track && detail.track.sub) || "map";
    var prevPos = detail.track && detail.track.pos;
    detail.track = Object.assign({}, detail.track || {}, { sub: keepSub, loading: true, pos: prevPos, err: null });
    var btn = $("trRefresh"); if (btn) { btn.disabled = true; btn.textContent = "Refreshing…"; }
    rpc("followme_fetch", { p_vessel: t.vessel_id }).then(function (data) {
      if (detail.id !== t.id) return;
      data = data || {};
      var meta = {
        at: data.at, hint: data.hint, attribution: data.attribution,
        warning: data.warning, next_in: data.next_in, stale: data.stale, cached: data.cached
      };
      if (data.error && data.body == null) {
        applyTrackResult(t, keepSub, prevPos, meta, { error: data.error });
        return;
      }
      var text = String(data.body == null ? "" : data.body);
      if (/your key is invalid|invalid key/i.test(text)) {
        applyTrackResult(t, keepSub, prevPos, meta, { error: "FollowMe says this API key is invalid. Re-save the vessel link." });
        return;
      }
      if (!text.trim()) {
        applyTrackResult(t, keepSub, prevPos, meta, { error: data.error || "FollowMe returned an empty response." });
        return;
      }
      var parsed = parseFollowmePayload(text);
      if (data.warning && parsed.pos) parsed.error = null;
      applyTrackResult(t, keepSub, prevPos, meta, parsed);
    }, function (e) {
      if (detail.id !== t.id) return;
      detail.track = { sub: keepSub, loading: false, pos: prevPos, err: (e && e.message) || "Could not load FollowMe.", at: Date.now() };
      if (detail.tab === "tracking") renderTrip();
    });
  }

  function renderTrip() {
    var id = detail.id, t = trips.filter(function (x) { return x.id === id; })[0];
    if (!t) { closeModal(); return; }
    var r = t.raw || {}, closed = CLOSED.indexOf(r.status) >= 0, m = detail.man || {}, c = m.counts || {};
    var paxCount = c.booked != null ? c.booked : (t.booked != null ? t.booked : 0);
    var crewN = (t.captain ? 1 : 0) + (detail.crew || []).length;
    if (detail.tab === "payments") detail.tab = "overview";
    var tabs = [
      ["overview", "Overview"],
      ["passengers", "Passengers", paxCount],
      ["crew", "Crew", crewN],
      ["tracking", "Tracking"],
      ["history", "Log"]
    ];
    var pct = loadPct(paxCount, t.capacity);
    var body = "";
    var loadingNote = m._loading ? '<p class="note">Loading…</p>' : "";
    var errNote = m._err ? '<p class="note td-err">Some passenger data could not load.</p>' : "";

    if (detail.tab === "overview") {
      var tasks = (queue || []).filter(function (x) { return x.trip_id === id && x.id; });
      var vCap = vesselOf(t);
      var crewCap = vCap && vCap.crew_capacity != null ? Number(vCap.crew_capacity) : null;
      var load = loadState(paxCount, t.capacity), f = crewFill({ captain: t.captain, crewCount: (detail.crew || []).length, vessel_id: t.vessel_id });
      var recent = (detail.events || []).slice(0, 4);
      body =
        loadingNote + errNote +
        loadBanner(paxCount, t.capacity, t.vessel || t.vesselCode) +
        '<div class="td-kpis tdx-kpis">' +
          '<div class="td-kpi tdx-load' + (load.cls ? " " + load.cls : "") + '"><span class="ops-ring" style="--p:' + Math.min(100, pct || 0) + '"><span><strong>' + (pct != null ? pct : "—") + '%</strong><small>' + (load.label || "full") + '</small></span></span><span><small>Passenger seats</small><strong>' + esc(paxCount + (t.capacity != null ? " / " + t.capacity : "")) + '</strong>' +
            (crewCap != null ? '<em class="td-cap-note">+ ' + crewCap + ' crew seats</em>' : "") + '</span></div>' +
          kpi("Checked in", c.checked_in || 0, null, I.ok, "teal") +
          kpi("Boarded", c.boarded || 0, null, I.boat, "blue") +
          kpi("Revenue", fmtMoney(c.revenue || 0), null, '<path d="M4 7h16v12H4zM4 11h16M8 15h3"/>', "violet") +
        '</div>' +
        '<div class="tdx-bento">' +
          '<section class="td-block tdx-b-seats"><div class="td-block-head"><h3>Seat map</h3><button type="button" class="linkish" data-dtab="passengers">Passenger list →</button></div>' + seatMap(t, c) + '</section>' +
          '<section class="td-block tdx-b-board"><div class="td-block-head"><h3>Boarding progress</h3></div>' + boardingFunnel(c) + '</section>' +
          '<section class="td-block tdx-b-crew"><div class="td-block-head"><h3>Crew on board</h3>' + (f.need ? fillChip({ captain: t.captain, crewCount: (detail.crew || []).length, vessel_id: t.vessel_id }) : "") + '</div>' +
            (mixOf(t).length ? crewSeats(t) : '<p class="note">' + esc(t.captain ? "Capt. " + t.captain : "No captain yet") + (crewN > 1 ? " + " + (crewN - 1) + " crew" : "") + '. Set seats by role in Vessel crew needs.</p>') +
            '<p class="td-inline-act"><button type="button" class="linkish" data-dtab="crew">Manage crew →</button></p></section>' +
          '<section class="td-block tdx-b-vessel">' +
            '<div class="td-block-head"><h3>Vessel &amp; captain</h3>' +
              (r.cleared_at ? '<span class="chip st-on-time">Cleared</span>' : '<span class="chip st-scheduled">Not cleared</span>') +
            '</div>' +
            (canOps && !closed
              ? '<div class="cards">' +
                  '<div class="fld"><label for="aVessel">Vessel</label><select id="aVessel">' +
                    options((vessels || []).filter(function (v) { return v.status !== "Out of service" || v.id === r.vessel_id; }).map(function (v) { return { id: v.id, name: (v.code ? v.code + " · " : "") + v.name + (v.passenger_capacity ? " (" + v.passenger_capacity + " seats)" : "") }; }), r.vessel_id || "", "No vessel") + '</select></div>' +
                  '<div class="fld"><label for="aCaptain">Captain</label><select id="aCaptain">' + options(staff || [], r.captain_id || "", "No captain") + '</select></div>' +
                '</div><p class="td-inline-act"><button type="button" class="btn-soft" id="aSave">Save</button></p>'
              : '<p class="td-plain"><strong>' + esc(t.vessel || "No vessel") + '</strong> · ' + esc(t.captain || "No captain") + '</p>') +
          '</section>' +
          '<section class="td-block tdx-b-log"><div class="td-block-head"><h3>Latest activity</h3><button type="button" class="linkish" data-dtab="history">Full log →</button></div>' +
            (recent.length ? '<ol class="tdx-log compact">' + recent.map(logItem).join("") + '</ol>' : '<p class="note">' + (m._loading ? "Loading…" : "Nothing logged yet.") + '</p>') + '</section>' +
          (tasks.length
            ? '<section class="td-block tdx-b-tasks"><div class="td-block-head"><h3>Open tasks</h3><span class="chip st-delayed">' + tasks.length + '</span></div><div class="ops-tasks">' + tasks.map(function (x) {
                return '<div class="ops-task"><span class="grow"><strong>' + esc(x.title) + '</strong><small>' + esc(x.sub || "Dispatch task") + '</small></span>' +
                  (canOps ? '<button type="button" class="btn-soft" data-done="' + esc(x.id) + '">Done</button>' : "") + '</div>';
              }).join("") + '</div></section>' : "") +
        '</div>' +
        dispatchBar(t, closed);
    } else if (detail.tab === "passengers") {
      var canAddPax = canOps && !closed && r.status !== "Departed" && r.status !== "In transit" && !m._loading;
      var openPax = detail.paxId
        ? (m.passengers || []).filter(function (x) { return x.id === detail.paxId; })[0]
        : null;
      if (detail.paxId && !openPax && !m._loading) { detail.paxId = null; detail.paxExtra = null; }
      if (openPax) {
        body = errNote + paxDetailView(openPax, closed, t);
        // Flag for CSS: detail canvas vs list board.
        detail._paxDetail = true;
      } else {
        detail._paxDetail = false;
        var allPax = m.passengers || [];
        var waiting = allPax.filter(function (p) { return !paxGone(p) && p.status === "Booked"; }).length;
        body = errNote +
          (m._loading
            ? '<section class="plx-hero skel"><div class="plx-hero-ring"><div class="plx-skel-ring"></div><div class="plx-hero-meta"><span class="ln w50"></span><span class="ln w30"></span></div></div><div class="plx-kpis">' +
                [0, 1, 2, 3].map(function () { return '<div class="plx-kpi sk"></div>'; }).join("") + '</div></section>'
            : paxBoardHero(allPax, c, t)) +
          paxCommandBar(canAddPax, closed, waiting) +
          (canAddPax && detail.addPax
            ? '<section class="td-block td-add plx-add" id="bAddForm">' +
                '<div class="td-block-head"><h3>New passenger booking</h3></div>' +
                '<div class="cards">' +
                  '<div class="fld"><label for="bName">Contact name</label><input id="bName" maxlength="120"></div>' +
                  '<div class="fld"><label for="bPhone">Phone</label><input id="bPhone" maxlength="40"></div>' +
                '</div><div id="bPax"></div>' +
                '<p class="td-inline-act"><button type="button" class="btn-soft" id="bAddPax">+ Another passenger</button></p>' +
                '<div class="cards">' +
                  '<div class="fld"><label for="bPaid">Paid now (' + esc(baseCurrency().code) + ')</label><input id="bPaid" type="number" min="0" step="0.01" placeholder="0"></div>' +
                  '<div class="fld"><label for="bMethod">Payment method</label><select id="bMethod"><option value="">—</option>' +
                    payMethods().map(function (x) { return '<option>' + esc(x) + '</option>'; }).join("") + '</select></div>' +
                '</div>' + payCurrencyNote() +
                '<p class="td-inline-act"><button type="button" class="save" id="bSave">Save booking</button></p>' +
              '</section>'
            : "") +
          '<div class="td-pax-scroll">' +
            (m._loading ? paxSkeleton() : paxList(allPax, closed)) +
          '</div>';
      }
    } else if (detail.tab === "crew") {
      body =
        (canOps && !closed
          ? '<section class="td-block"><div class="td-block-head"><h3>Captain &amp; vessel</h3></div>' +
              '<div class="cards">' +
                '<div class="fld"><label for="aCaptain">Captain</label><select id="aCaptain">' + options(staff || [], r.captain_id || "", "No captain") + '</select></div>' +
                '<div class="fld"><label for="aVessel">Vessel</label><select id="aVessel">' +
                  options((vessels || []).filter(function (v) { return v.status !== "Out of service" || v.id === r.vessel_id; }), r.vessel_id || "", "No vessel") + '</select></div>' +
              '</div><p class="td-inline-act"><button type="button" class="btn-soft" id="aSave">Save</button></p></section>'
          : "") +
        '<section class="td-block tdx-crew-hero"><div class="td-block-head"><h3>Seats by role</h3>' + fillChip({ captain: t.captain, crewCount: (detail.crew || []).length, vessel_id: t.vessel_id }) + '</div>' +
          (mixOf(t).length ? crewSeats(t) : '<p class="note">This vessel has no crew needs yet. Set them under Operations → Crew → Vessel crew needs.</p>') +
          (canOps && !closed ? '<div class="tdx-crew-cta"><button type="button" class="save" id="cwAuto2">' + icon(I.people) + ' Fill open seats from the Duty Roster</button><small>Only empty seats are filled. People you chose by hand stay.</small></div>' : "") +
        '</section>' +
        '<section class="td-block"><div class="td-block-head"><h3>On this trip</h3></div>' + crewCards(t, closed) + '</section>' +
        (canOps && !closed
          ? '<section class="td-block td-add"><div class="td-block-head"><h3>Add crew</h3></div>' +
              '<div class="cards">' +
                '<div class="fld"><label for="cwUser">Person</label><select id="cwUser">' + options(staff || [], "", "Choose…") + '</select></div>' +
                '<div class="fld"><label for="cwRole">Role</label><select id="cwRole"><option>Crew</option><option>Cashier</option><option>Deck</option><option>Engineering</option><option>Cabin</option></select></div>' +
              '</div>' +
              '<p class="td-inline-act">' +
                '<button type="button" class="btn-soft" id="cwAdd">Add</button>' +

              '</p>' +
              '<p class="note">Manual picks are kept. Roster fill only adds empty places.</p></section>'
          : "");
    } else if (detail.tab === "tracking") {
      if (!detail.track) detail.track = { sub: "map", loading: false };
      body = trackingView(t);
    } else {
      var evs = detail.events || [], lf = detail.logF || "all", kinds = {};
      evs.forEach(function (e) { var k = eventKind(e); kinds[k] = (kinds[k] || 0) + 1; });
      var shownEv = evs.filter(function (e) { return lf === "all" || eventKind(e) === lf; }), days = [], byDay = {};
      shownEv.forEach(function (e) { var d = iso(new Date(e.created_at)); if (!byDay[d]) { byDay[d] = []; days.push(d); } byDay[d].push(e); });
      body = '<section class="td-block tdx-logbox"><div class="td-block-head"><h3>Trip log</h3><span class="muted-cell">' + evs.length + ' entries</span></div>' +
        '<div class="tdx-chips">' + [["all", "All"], ["status", "Status"], ["crew", "Crew"], ["booking", "Bookings"], ["auto", "Automatic"], ["created", "Created"]].filter(function (x) { return x[0] === "all" || kinds[x[0]]; }).map(function (x) {
          return '<button type="button" class="tdx-chip' + (lf === x[0] ? " on" : "") + '" data-logf="' + x[0] + '">' + x[1] + '<b>' + (x[0] === "all" ? evs.length : kinds[x[0]]) + '</b></button>';
        }).join("") + '</div>' +
        (shownEv.length ? days.map(function (d) {
          return '<div class="tdx-logday"><span class="tdx-logday-h">' + esc(dayLabel(d)) + '</span><ol class="tdx-log">' + byDay[d].map(logItem).join("") + '</ol></div>';
        }).join("") : (m._loading ? '<p class="note">Loading…</p>' : '<div class="tdx-empty">' + icon(I.clock) + '<strong>Nothing logged yet</strong></div>')) +
      '</section>';
    }

    var tabsHtml = '<div class="ops-tabs seg ops-dtabs td-tabs">' + tabs.map(function (x) {
      return '<button type="button" class="' + (detail.tab === x[0] ? "on" : "") + '" data-dtab="' + x[0] + '">' + esc(x[1]) + (x[2] != null ? '<b>' + x[2] + '</b>' : "") + '</button>';
    }).join("") + '</div>';
    // Passengers tab: only tabs + list. Overview keeps dispatch actions at the bottom of the body.
    var chrome = detail.tab === "passengers"
      ? '<header class="td-pax-top">' +
          '<div class="td-pax-top-id"><strong>' + esc(t.code || "Trip") + '</strong>' +
            '<span>' + esc((t.origin || "") + (t.destination ? " → " + t.destination : "")) + '</span></div>' +
          '<button type="button" class="td-close" data-close aria-label="Close">' + icon(I.close) + '</button>' +
        '</header>' + tabsHtml
      : tripHero(t) + tabsHtml;
    openModal(
      chrome +
      '<div class="td-body' + (detail.tab === "passengers" ? " is-pax" : "") + (detail._paxDetail ? " is-pax-detail" : "") + '">' + body + '<p class="msg" id="mMsg" role="status"></p></div>',
      true,
      detail.tab === "passengers"
    );
    bindTrip(id);
    if (detail.tab === "tracking") {
      paintTrackMap();
      if (!detail.track || (!detail.track.loading && !detail.track.at)) loadTripTracking(false);
      if (!trackTimer) trackTimer = setInterval(function () {
        if (detail.tab !== "tracking" || $("modal").hidden) { destroyTrackMap(); return; }
        loadTripTracking(true);
      }, 60000);
    } else {
      destroyTrackMap();
    }
  }

  function paxRow() {
    var cats = listSetting("7_passenger_categories", ["Adult", "Child", "Infant", "Senior", "Student", "Resident", "Tourist"]);
    var el = document.createElement("div");
    el.className = "cards ops-paxin";
    el.innerHTML = '<div class="fld"><label>Passenger name</label><input data-f="full_name" maxlength="120"></div>' +
      '<div class="fld"><label>ID / passport</label><input data-f="id_number" maxlength="60"></div>' +
      '<div class="fld"><label>Category</label><select data-f="category">' + cats.map(function (x) { return '<option>' + esc(x) + '</option>'; }).join("") + '</select></div>' +
      '<div class="fld"><label>Fare (blank = route fare)</label><input data-f="fare" type="number" min="0" step="0.01"></div>';
    $("bPax").appendChild(el);
  }

  function bindTrip(id) {
    function after(p, keepTab) {
      p.then(function () { return Promise.all([loadData(), loadDetail(id)]); })
       .then(function () { render(); renderTrip(); }, function (e) { say(e.message, "err"); });
    }
    [].forEach.call($("modalCard").querySelectorAll("[data-dtab]"), function (b) {
      b.addEventListener("click", function () {
        detail.tab = b.dataset.dtab;
        if (detail.tab !== "passengers") { detail.addPax = false; detail.paxId = null; detail.paxExtra = null; }
        if (detail.tab !== "tracking") destroyTrackMap();
        renderTrip();
      });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-track-sub]"), function (b) {
      b.addEventListener("click", function () {
        detail.track = detail.track || {};
        detail.track.sub = b.dataset.trackSub;
        renderTrip();
      });
    });
    if ($("trRefresh")) $("trRefresh").addEventListener("click", function () { loadTripTracking(true); });
    if ($("bAddOpen")) $("bAddOpen").addEventListener("click", function () { detail.addPax = true; detail.paxId = null; renderTrip(); });
    if ($("paxBack")) $("paxBack").addEventListener("click", function () { detail.paxId = null; detail.paxExtra = null; renderTrip(); });
    [].forEach.call($("modalCard").querySelectorAll("[data-pax-open]"), function (card) {
      function go() { openPaxDetail(card.dataset.paxOpen); }
      card.addEventListener("click", function (e) {
        if (e.target.closest && e.target.closest("button, a, select, input, [data-stop-open], .plx-c-pay, .plx-c-board, .plx-c-foot")) return;
        go();
      });
      card.addEventListener("keydown", function (e) {
        if (e.target.closest && e.target.closest("button, a, select, input, .plx-c-pay, .plx-c-board, .plx-c-foot")) return;
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); }
      });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-pxf]"), function (b) { b.addEventListener("click", function () { detail.paxF = b.dataset.pxf; renderTrip(); }); });
    [].forEach.call($("modalCard").querySelectorAll("[data-pxview]"), function (b) {
      b.addEventListener("click", function () { detail.paxView = b.dataset.pxview; renderTrip(); });
    });
    if ($("pxSort")) $("pxSort").addEventListener("change", function () { detail.paxSort = this.value; renderTrip(); });
    [].forEach.call($("modalCard").querySelectorAll("[data-logf]"), function (b) { b.addEventListener("click", function () { detail.logF = b.dataset.logf; renderTrip(); }); });
    if ($("pxQ")) $("pxQ").addEventListener("input", function () {
      var v = this.value, pos = this.selectionStart; detail.paxQ = v; renderTrip();
      var n = $("pxQ"); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} }
    });
    if ($("pxCheckAll")) $("pxCheckAll").addEventListener("click", function () {
      var ids = ((detail.man || {}).passengers || []).filter(function (p) { return !paxGone(p) && p.status === "Booked"; }).map(function (p) { return p.id; });
      if (!ids.length) return;
      this.disabled = true; say("Checking in " + ids.length + "…");
      after(ids.reduce(function (pr, pid) { return pr.then(function () { return rpc("set_passenger_status", { p_id: pid, p_status: "Checked in" }); }); }, Promise.resolve()));
    });
    if ($("cwAuto2")) $("cwAuto2").addEventListener("click", function () { this.disabled = true; say("Checking the roster…"); after(rpc("assign_trip_crew", { p_company: company.id })); });
    if ($("bAddCancel")) $("bAddCancel").addEventListener("click", function () { detail.addPax = false; renderTrip(); });
    [].forEach.call($("modalCard").querySelectorAll("[data-print]"), function (b) {
      b.addEventListener("click", function () {
        detail.tab = "passengers";
        renderTrip();
        setTimeout(function () { window.print(); }, 120);
      });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-act]"), function (b) {
      b.addEventListener("click", function () {
        var a = b.dataset.act;
        var reason = "";
        if ($("cReason") && $("cReason").value) reason = $("cReason").value.trim();
        if ($("cReasonOther") && $("cReasonOther").value.trim()) reason = $("cReasonOther").value.trim();
        if ((a === "Delayed" || a === "Cancelled") && !reason) {
          var why = $("cWhy"); if (why) { why.open = true; why.classList.remove("need"); void why.offsetWidth; why.classList.add("need"); why.scrollIntoView({ block: "nearest", behavior: "smooth" }); }
          say("Pick or type a reason first.", "err"); return;
        }
        if (a === "Cancelled" && !window.confirm("Cancel this trip? Booked passengers will be refunded per your Cancellation rules.")) return;
        say("Saving…");
        if (a === "clear") {
          after(rpc("clear_trip", { p_id: id, p_checks: { weather: !!($("cWeather") && $("cWeather").checked), checklist: !!($("cCheck") && $("cCheck").checked) } }));
        } else {
          after(rpc("set_trip_status", { p_id: id, p_status: a, p_reason: reason || null }));
        }
      });
    });
    // Pre-departure checks: live "x of 2 done" count.
    function countChecks() {
      var boxes = [$("cWeather"), $("cCheck")].filter(Boolean), done = boxes.filter(function (x) { return x.checked; }).length;
      if ($("cCount")) { $("cCount").textContent = done + " of " + boxes.length + " done"; $("cCount").classList.toggle("all", done === boxes.length); }
    }
    ["cWeather", "cCheck"].forEach(function (k) { if ($(k)) $(k).addEventListener("change", countChecks); });
    // Reason chips drive the (hidden) reason select; typing your own clears the chip.
    [].forEach.call($("modalCard").querySelectorAll("[data-reason]"), function (b) {
      b.addEventListener("click", function () {
        var on = b.getAttribute("aria-checked") !== "true";
        [].forEach.call($("modalCard").querySelectorAll("[data-reason]"), function (o) { o.setAttribute("aria-checked", "false"); });
        b.setAttribute("aria-checked", on ? "true" : "false");
        $("cReason").value = on ? b.dataset.reason : "";
        if (on && $("cReasonOther")) $("cReasonOther").value = "";
        if ($("cWhyHint")) $("cWhyHint").textContent = on ? "Reason: " + b.dataset.reason + ". Now press Delay or Cancel." : "Pick a reason first, then press Delay or Cancel";
        $("cWhy").classList.remove("need");
      });
    });
    if ($("cReasonOther")) $("cReasonOther").addEventListener("input", function () {
      if (!this.value.trim()) return;
      [].forEach.call($("modalCard").querySelectorAll("[data-reason]"), function (o) { o.setAttribute("aria-checked", "false"); });
      $("cReason").value = "";
      if ($("cWhyHint")) $("cWhyHint").textContent = "Your reason is ready. Now press Delay or Cancel.";
      $("cWhy").classList.remove("need");
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-role-user]"), function (sel) {
      sel.addEventListener("change", function () {
        say("Updating role…");
        after(db.from("trip_crew").update({ role: sel.value }).eq("trip_id", id).eq("user_id", sel.dataset.roleUser)
          .then(function (res) { if (res.error) throw new Error(res.error.message); }));
      });
    });
    if ($("aSave")) $("aSave").addEventListener("click", function () {
      say("Saving…");
      after(db.from("trips").update({ vessel_id: $("aVessel").value || null, captain_id: $("aCaptain").value || null }).eq("id", id)
        .then(function (res) { if (res.error) throw new Error(res.error.message); }));
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-done]"), function (b) {
      b.addEventListener("click", function () { after(rpc("finish_dispatch_task", { p_id: b.dataset.done })); });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-pax]"), function (b) {
      b.addEventListener("click", function (e) {
        e.stopPropagation();
        say("Saving…"); after(rpc("set_passenger_status", { p_id: b.dataset.pax, p_status: b.dataset.st }));
      });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-cancelbk]"), function (b) {
      b.addEventListener("click", function (e) {
        e.stopPropagation();
        if (!window.confirm("Cancel this whole booking? The refund is worked out from your Cancellation & Refund Rules.")) return;
        say("Cancelling…");
        after(rpc("cancel_booking", { p_id: b.dataset.cancelbk, p_reason: "Cancelled at the counter" }).then(function (res) {
          detail.paxId = null; detail.paxExtra = null;
          return res;
        }));
      });
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-markpaid]"), function (b) {
      b.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        var cell = b.closest(".plx-c-pay, .plx-pay-cell");
        var listMeth = cell && cell.querySelector(".plx-list-meth");
        var method = (listMeth && listMeth.value) || ($("pxPayMethod") && $("pxPayMethod").value) || null;
        b.disabled = true;
        say("Recording payment…");
        after(markBookingPaid(b.dataset.markpaid, method).then(function (res) {
          if (detail.paxId && res) {
            detail.paxExtra = Object.assign({}, detail.paxExtra || {}, {
              payment_status: res.payment_status,
              paid_amount: res.paid_amount,
              payment_method: res.payment_method,
              fare_total: res.fare_total,
              _loading: false,
              _err: false
            });
          }
          return res;
        }, function (err) {
          b.disabled = false;
          throw err;
        }));
      });
    });
    if ($("bPax")) { paxRow(); $("bAddPax").addEventListener("click", paxRow); }
    if ($("bSave")) $("bSave").addEventListener("click", function () {
      var pax = [].map.call($("bPax").querySelectorAll(".ops-paxin"), function (row) {
        var o = {};
        [].forEach.call(row.querySelectorAll("[data-f]"), function (i) { if (i.value.trim() !== "") o[i.dataset.f] = i.value.trim(); });
        return o;
      }).filter(function (o) { return o.full_name; });
      if (!pax.length) { say("Add at least one passenger name.", "err"); return; }
      var trip = trips.filter(function (x) { return x.id === id; })[0];
      var nextBooked = (trip && trip.booked != null ? Number(trip.booked) : 0) + pax.length;
      var nextLoad = trip ? loadState(nextBooked, trip.capacity) : { level: "" };
      say("Saving booking…");
      after(rpc("create_booking", {
        p_company: company.id, p_trip: id,
        p_booking: { contact_name: $("bName").value.trim() || pax[0].full_name, contact_phone: $("bPhone").value.trim(), source: "Manual",
                     paid_amount: $("bPaid").value || 0, payment_method: $("bMethod").value || null },
        p_passengers: pax
      }).then(function (res) {
        detail.addPax = false;
        var boat = (trip && (trip.vessel || trip.vesselCode)) || "Vessel";
        if (nextLoad.level === "full") boardToast(boat + " is now full.");
        else if (nextLoad.level === "almost") boardToast(boat + " is almost full.");
        return res;
      }));
    });
    [].forEach.call($("modalCard").querySelectorAll("[data-uncrew]"), function (b) {
      b.addEventListener("click", function () {
        after(db.from("trip_crew").delete().eq("trip_id", id).eq("user_id", b.dataset.uncrew).then(function (res) { if (res.error) throw new Error(res.error.message); }));
      });
    });
    if ($("cwAdd")) $("cwAdd").addEventListener("click", function () {
      if (!$("cwUser").value) { say("Choose a person.", "err"); return; }
      after(db.from("trip_crew").insert({ trip_id: id, company_id: company.id, user_id: $("cwUser").value, role: $("cwRole").value })
        .then(function (res) { if (res.error) throw new Error(res.error.message); }));
    });
    if ($("cwAuto")) $("cwAuto").addEventListener("click", function () {
      say("Checking the roster…");
      after(rpc("assign_trip_crew", { p_company: company.id }));
    });
  }

  function openTask(taskId) {
    var x = queue.filter(function (k) { return k.id === taskId; })[0];
    if (!x) return;
    openModal('<h2>' + esc(x.title) + '</h2><p class="note">' + esc(x.sub || "") + '</p><p class="msg" id="mMsg" role="status"></p>' +
      '<div class="modal-actions"><button type="button" class="ghost" data-close>Close</button>' +
      (canOps ? '<button type="button" class="ghost" id="kSkip">Dismiss</button><button type="button" class="save" id="kDone">Mark done</button>' : "") + '</div>');
    function fin(ok) {
      rpc("finish_dispatch_task", { p_id: taskId, p_done: ok }).then(function () { closeModal(); reload(); }, function (e) { say(e.message, "err"); });
    }
    if ($("kDone")) $("kDone").addEventListener("click", function () { fin(true); });
    if ($("kSkip")) $("kSkip").addEventListener("click", function () { fin(false); });
  }

  function say(t, k) { var m = $("mMsg"); if (m) { m.textContent = t; m.className = "msg " + (k || ""); } }
  function openModal(html, tripFull, paxOnly) {
    $("modal").classList.toggle("is-trip", !!tripFull);
    document.documentElement.classList.toggle("ops-trip-open", !!tripFull);
    document.body.classList.toggle("ops-trip-open", !!tripFull);
    $("modalCard").className = tripFull
      ? ("modal-card ops-detail tdx" + (paxOnly ? " is-pax" : ""))
      : "modal-card sch-modal";
    $("modalCard").innerHTML = html;
    $("modal").hidden = false;
    var f = !tripFull && $("modalCard").querySelector("input,select,textarea");
    if (f) f.focus();
  }
  function closeModal() {
    destroyTrackMap();
    $("modal").hidden = true;
    $("modal").classList.remove("is-trip");
    document.documentElement.classList.remove("ops-trip-open");
    document.body.classList.remove("ops-trip-open");
    $("modalCard").className = "modal-card";
    $("modalCard").innerHTML = "";
  }

  function clearDay() { dayF = ""; render(); }
  function boardToast(msg, err) {
    var el = document.createElement("p");
    el.className = "msg" + (err ? " err" : "");
    el.textContent = msg;
    var host = document.querySelector(".ops-main");
    if (host) { host.insertBefore(el, host.firstChild.nextSibling); setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 4000); }
  }
  function bind() {
    [].forEach.call(document.querySelectorAll("#ops [data-tab]"), function (b) {
      b.addEventListener("click", function () { tab = b.dataset.tab; render(); });
    });
    if ($("opsDay")) $("opsDay").addEventListener("change", function () {
      dayF = $("opsDay").value || "";
      if (dayF && tab !== "crew") {
        var today = todayIso();
        if (dayF === today) tab = "today";
        else if (dayF > today) tab = "upcoming";
      }
      render();
    });
    if ($("clearDay")) $("clearDay").addEventListener("click", clearDay);
    if ($("clearDayTop")) $("clearDayTop").addEventListener("click", clearDay);
    if ($("opsStatus")) $("opsStatus").addEventListener("change", function () { statusF = $("opsStatus").value; render(); });
    if ($("opsRoute")) $("opsRoute").addEventListener("change", function () { routeF = $("opsRoute").value; render(); });
    if ($("opsVessel")) $("opsVessel").addEventListener("change", function () { vesselF = $("opsVessel").value; render(); });
    if ($("opsQ")) $("opsQ").addEventListener("input", function () {
      q = $("opsQ").value.trim(); render();
      var i = $("opsQ"); i.focus(); i.setSelectionRange(i.value.length, i.value.length);
    });
    if ($("opsNew")) $("opsNew").addEventListener("click", openNewTrip);
    if ($("emptyNew")) $("emptyNew").addEventListener("click", openNewTrip);
    if ($("opsAssign")) $("opsAssign").addEventListener("click", function () { openAssign(null); });
    [].forEach.call(document.querySelectorAll("#ops [data-assign]"), function (b) {
      b.addEventListener("click", function (e) { e.stopPropagation(); openAssign(b.dataset.assign); });
    });
    [].forEach.call(document.querySelectorAll("#ops [data-unassign]"), function (b) {
      b.addEventListener("click", function (e) {
        e.stopPropagation();
        db.from("trips").update({ vessel_id: null }).eq("id", b.dataset.unassign).then(function (res) {
          if (res.error) { boardToast(res.error.message, true); return; }
          boardToast("Vessel removed.");
          reload();
        });
      });
    });
    if ($("vesselCrewNeeds")) $("vesselCrewNeeds").addEventListener("click", function () { window.VeyoraVesselCrew.open({ db: db, company: company, onSaved: reload }); });
    if ($("crewAutoAll") && canOps) {
      $("crewAutoAll").addEventListener("click", function () {
        boardToast("Filling empty crew places from the roster…");
        rpc("assign_trip_crew", { p_company: company.id }).then(function () { return reload(); }, function (e) { boardToast(e.message, true); });
      });
    }
    [].forEach.call(document.querySelectorAll("#ops [data-captain-trip]"), function (sel) {
      sel.addEventListener("change", function () {
        var tid = sel.dataset.captainTrip;
        db.from("trips").update({ captain_id: sel.value || null }).eq("id", tid).then(function (res) {
          if (res.error) { boardToast(res.error.message, true); return; }
          boardToast("Captain updated");
          reload();
        });
      });
    });
    [].forEach.call(document.querySelectorAll("#ops [data-board-add]"), function (btn) {
      btn.addEventListener("click", function () {
        var tid = btn.dataset.boardAdd;
        var user = document.querySelector('[data-add-user="' + tid + '"]');
        var role = document.querySelector('[data-add-role="' + tid + '"]');
        if (!user || !user.value) { boardToast("Choose a person first.", true); return; }
        db.from("trip_crew").insert({ trip_id: tid, company_id: company.id, user_id: user.value, role: (role && role.value) || "Crew" })
          .then(function (res) {
            if (res.error) { boardToast(res.error.message, true); return; }
            boardToast("Crew member added");
            reload();
          });
      });
    });
    [].forEach.call(document.querySelectorAll("#ops [data-board-uncrew]"), function (btn) {
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        db.from("trip_crew").delete().eq("trip_id", btn.dataset.boardUncrew).eq("user_id", btn.dataset.uid).then(function (res) {
          if (res.error) { boardToast(res.error.message, true); return; }
          boardToast("Removed from trip");
          reload();
        });
      });
    });
    [].forEach.call(document.querySelectorAll("#ops [data-trip]"), function (b) {
      function go() { openTrip(b.dataset.trip, b.dataset.opentab || null); }
      b.addEventListener("click", function (e) { e.stopPropagation(); go(); });
      b.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); }
      });
    });
    [].forEach.call(document.querySelectorAll("#ops [data-task]"), function (b) {
      function go() { openTask(b.dataset.task); }
      b.addEventListener("click", go);
      b.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); }
      });
    });
  }

  $("modal").addEventListener("click", function (e) { if (e.target === $("modal") || e.target.closest("[data-close]")) closeModal(); });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (assign) { closeAssign(); return; }
    if (!$("modal").hidden) closeModal();
  });

  window.VeyoraShell.start({
    active: "Operations",
    onCompany: function (c, info) {
      company = c;
      canOps = !!(info.canAll || info.canOps || info.isPlatform || info.isAdmin || info.myRole === "operations");
      $("ops").innerHTML = '<p class="msg">Loading…</p>';
      reload();
      // The database moves trips on by the clock every minute; refresh the board to match (not while a window is open).
      setInterval(function () { if ($("modal").hidden && !document.hidden) reload(); }, 60000);
      // Countdowns tick every 15 seconds without redrawing the board.
      setInterval(function () { [].forEach.call(document.querySelectorAll("[data-until]"), function (el) { if (el.dataset.until) el.textContent = (el.dataset.prefix || "") + untilText(Number(el.dataset.until) - Date.now()); }); }, 15000);
      if (window.VeyoraTip) window.VeyoraTip("ops3", [
        "**Operations** is the live dispatch board — today’s trips and crew.",
        "Use the **Crew** tab to change captains and crew members. Open a trip for full details.",
        "**Delayed** is only set when you mark it yourself with a reason — never automatically."
      ]);
    },
    onNone: function () { $("ops").innerHTML = '<section class="dash-card"><h2>No company yet</h2><p class="note">Ask your administrator for an invite.</p></section>'; },
    onError: function (err) { $("ops").innerHTML = '<section class="dash-card"><h2>Could not load Operations</h2><p class="note">' + esc(err.message) + '</p></section>'; }
  });
})();
